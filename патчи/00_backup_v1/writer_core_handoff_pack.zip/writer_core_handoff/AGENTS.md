# AGENTS.md — нормативная инструкция агентам разработки

## 1. Миссия

Разрабатывать Writer Core 2 как typed, auditable, dependency-aware document compiler.

Не строить «агента, который хорошо пишет». Строить систему, в которой генеративная модель является сменным исполнителем строго ограниченных semantic operations.

## 2. Неподвижные инварианты

1. LLM **не имеет прямой записи** в authoritative state.
2. Document containment, epistemics, discourse, artifacts, provenance и execution — разные модели.
3. `Section` и `Paragraph` не являются epistemic Claim.
4. Source != Evidence. Summary != Evidence.
5. Writer не повышает доказательную силу claim.
6. Любая prose realization после генерации проходит round-trip semantic validation.
7. Числа, формулы, таблицы, рисунки и citations имеют stable IDs и provenance.
8. Изменение upstream dependency инвалидирует downstream units.
9. Шаблон — typed artifact, не prompt fragment.
10. Один scalar `confidence` не заменяет typed statuses.
11. Ошибка критического validator-а должна fail closed.
12. Любой автоматический repair снова проходит RTT.

## 3. Источники истины

- Static program/config: YAML в Git (`schemas/`, `templates/`, `policies/`).
- Runtime authoritative state: SQLite + append-only event log.
- Research epistemics: Researcher Core projection, read-only для Writer.
- Markdown/DOCX/PDF: build artifacts, не truth store.

## 4. Что агент обязан сделать перед кодированием

Для каждой задачи агент записывает краткий implementation note:

```yaml
operation:
  goal:
  reads:
  writes:
  invariants_touched:
  deterministic_part:
  model_assisted_part:
  failure_modes:
  tests:
```

Если нельзя точно назвать `reads` и `writes`, задача ещё не декомпозирована.

## 5. Запрещённые архитектурные shortcuts

- универсальный `Node(type, payload, edges)` вместо typed domain entities;
- `paragraph.claims = [...]` без relation objects и provenance;
- hidden mutation из LLM callbacks;
- prompt как единственное место хранения business rules;
- auto-approve от reviewer-agent;
- применение corpus reference как factual evidence нового документа;
- raw reference paragraph как template;
- rebuild всего документа при локальном изменении без dependency closure;
- смешивание lifecycle/review/validation в одном enum.

## 6. Порядок реализации

Всегда соблюдать dependency order из `docs/09_IMPLEMENTATION_MASTER_PLAN.md`.

Не начинать M6+ до прохождения acceptance gate предыдущей фазы.

## 7. Handoff между агентами

Каждый завершённый task обязан оставить:

- изменённые файлы;
- тесты;
- fixture;
- `decision_record` при архитектурном выборе;
- список известных дыр;
- migration note при изменении schema.

Фраза «работает» без теста или fixture не считается handoff.
