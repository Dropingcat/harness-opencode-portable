# Architecture Decision Log — seed

## ADR-001 — Separate document containment from epistemic graph
Status: ACCEPTED

Rationale: section/paragraph/sentence are communicative containers, not epistemic claims. Mixing them creates invalid semantics for SUPPORTS/CONTRADICTS/confidence/status propagation.

## ADR-002 — Static YAML, runtime SQLite + event log
Status: PROPOSED FOR IMPLEMENTATION

YAML remains canonical for schemas/templates/policies. Runtime writer state is authoritative in SQLite/event log. This removes ambiguous bidirectional YAML<->SQLite synchronization.

## ADR-003 — Mandatory RTT after semantic prose generation
Status: ACCEPTED

Every prose mutation that can alter factual meaning must be back-extracted and compared against its Writing Contract.

## ADR-004 — LLM proposals cannot mutate registry directly
Status: ACCEPTED

All semantic changes pass typed application commands and validators.

## ADR-005 — Similarity is diagnostic, not truth/quality scalar
Status: ACCEPTED

Reference similarity may inform style/structure selection but cannot replace epistemic fidelity, argument validity or originality gates.
