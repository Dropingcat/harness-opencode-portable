# Manifest

## Normative
- README.md
- AGENTS.md
- DECISIONS.md
- TASKS.md
- docs/*.md
- schemas/*.yaml
- templates/*.yaml
- policies/*.yaml

## Executable examples / skeleton
- examples/**/*.yaml
- src_skeleton/writer_core_ir/*.py
- tests/*

## Legacy source material
- legacy_sources/ARCHITECTURE.md
- legacy_sources/ARCHITECTURE-REVIEW.md
- legacy_sources/DESIGN-SELF-LEARNING-WRITER.md
- legacy_sources/YAML-SKELETON-SPEC.md
- legacy_sources/RESEARCHER-ARCHITECTURE.md
- legacy_sources/researcher_fixture.yaml
- legacy_sources/pyproject.toml
- legacy_sources/writer-core-original.7z
