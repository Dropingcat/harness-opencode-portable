# Writer Core 2 — Agent Handoff Pack

Нормативный пакет для разработки Writer Core как **компилятора профессионального документа**, а не как свободного LLM-райтера.

## Главная идея

Researcher отвечает: **что известно и с какой доказательной силой**.
Writer отвечает: **как построить из этого знания документ, не исказив смысл, структуру, числа, формулы, артефакты и provenance**.

Ключевой цикл:

```text
Researcher Projection
  -> Writing Contract
  -> Writing Decomposition DAG
  -> Discourse/Argument/Artifact planning
  -> Realization
  -> Document IR
  -> Round-trip Semantic Validation
  -> Dependency invalidation / repair
  -> Review
  -> Export
```

## Порядок чтения для агента

1. `AGENTS.md` — правила работы и границы полномочий.
2. `docs/01_INVARIANTS.md` — что нельзя нарушать.
3. `docs/02_ARCHITECTURE.md` — общая архитектура.
4. `docs/03_ENTITY_AND_GRAPH_REGISTRY.md` — сущности, деревья и графы.
5. `docs/04_ROUTING.md` — маршрутизация и операции.
6. `docs/05_WRITING_CONTRACT.md` — интерфейс Researcher -> Writer.
7. `docs/06_ROUND_TRIP_SEMANTIC_VALIDATION.md` — обратная семантическая проверка.
8. `docs/07_TEMPLATE_SYSTEM.md` — шаблоны как типизированные артефакты.
9. `docs/08_AGENT_ROLES.md` — роли агентов и handoff.
10. `docs/09_IMPLEMENTATION_MASTER_PLAN.md` — генеральный план.
11. `docs/10_TEST_AND_ACCEPTANCE.md` — Definition of Done.
12. `docs/11_MIGRATION.md` — перенос текущего writer-core.

## Что является нормативным

Новые документы этого пакета имеют приоритет над `legacy_sources/`. Старые документы сохранены для трассировки решений и миграции, но не являются единственным источником истины новой архитектуры.

## Минимальный vertical slice

Система должна сначала идеально уметь собрать **один академический абзац**:

```text
2-4 разрешённых claims
+ 0-2 quantities
+ 1 citation/evidence chain
+ discourse intent
-> paragraph
-> back-extracted claims
-> semantic diff
-> PASS/FAIL with machine-readable reason codes
```

До прохождения этого среза запрещено усложнять систему graph mining, multi-agent orchestration и тяжёлой инфраструктурой.
