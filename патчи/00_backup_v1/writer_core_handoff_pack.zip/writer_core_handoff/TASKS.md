# Initial Backlog

## Epic E0 — Contracts
- [ ] Freeze ID conventions.
- [ ] Freeze relation enums.
- [ ] Freeze reason-code registry.
- [ ] Define SQLite schema v0.1.
- [ ] Write migration adapter from legacy WriterUnit.

## Epic E1 — IR
- [ ] Document Tree entities.
- [ ] Discourse entities.
- [ ] Artifact/Symbol entities.
- [ ] Orthogonal status value objects.
- [ ] Event + revision entities.

## Epic E2 — Researcher bridge
- [ ] Import EpistemicProjection.
- [ ] Map scope/evidence/eligibility without loss.
- [ ] Generate ClaimWritingContract.

## Epic E3 — Paragraph compiler
- [ ] WritingObjective -> ParagraphIntent.
- [ ] ClaimSlot/ArtifactSlot.
- [ ] Template instantiation.
- [ ] Inline AST realization.

## Epic E4 — RTT
- [ ] BackExtraction schema.
- [ ] Claim aligner.
- [ ] Scope comparator.
- [ ] Modality/causality comparator.
- [ ] Numeric/object comparator.
- [ ] Repair planner.

## Epic E5 — Dependency
- [ ] Dependency edge registry.
- [ ] Impact closure.
- [ ] freshness transitions.
- [ ] selective rebuild.
