# 01. Architecture Invariants

## I-01. Separation of representations

Система использует отдельные представления для разных вопросов:

| Модель | Вопрос |
|---|---|
| Document Structure Tree | Где находится элемент? |
| Discourse Graph | Зачем этот фрагмент здесь? |
| Epistemic/Argument Graph | Что утверждается и на чём основано? |
| Artifact/Symbol Graph | Какие числа, формулы, таблицы, рисунки, код и термины используются? |
| Citation/Provenance Graph | Откуда это произошло? |
| Policy/Constraint Graph | Какие правила действуют? |
| Revision/Dependency Graph | Что устареет при изменении? |
| Execution Graph | Какая операция создала/изменила результат? |

Ни один граф не объявляется «универсальным» только ради удобства хранения.

## I-02. Researcher authority

Writer получает epistemic projection только на чтение. Новое содержательное утверждение, отсутствующее в разрешённой проекции, становится `WriterClaimCandidate` и блокирует release до reverify Researcher-ом или человеком.

## I-03. Semantic monotonicity

При realization Writer не имеет права самовольно:

- расширять scope;
- усиливать modality;
- повышать causal level;
- убирать обязательный qualifier;
- менять численное значение/единицу/точность;
- превращать correlation в causation;
- превращать `mixed/insufficient` evidence в уверенное утверждение.

## I-04. Round-trip requirement

Каждый изменённый `RealizationUnit` проходит обратное извлечение claims/objects и сравнение с Writing Contract.

## I-05. Dependency invalidation

Изменение Claim, Quantity, Formula, Dataset, Evidence, Policy или Template version создаёт dependency impact. Зависимые units получают `STALE`, `INVALID` или `REVERIFY_REQUIRED`; молчаливое сохранение `FRESH` запрещено.

## I-06. Typed validation

Validator обязан иметь класс:

- `STRUCTURAL`
- `SYMBOLIC`
- `RULE_BASED`
- `MODEL_ASSISTED`
- `HUMAN`
- `EXPERT`

Каждый verdict хранит validator/version/input hash/reason codes.

## I-07. Orthogonal states

Раздельно хранятся lifecycle, generation, validation, review, publication и freshness state.

## I-08. Artifact references

Числа и формулы в профессиональном тексте должны по возможности вставляться через object reference, а не дублироваться свободной строкой.

## I-09. Templates are executable specifications

Шаблон описывает slots, preconditions, relations, constraints и postconditions. Prompt может быть derived artifact шаблона, но не наоборот.

## I-10. Build artifacts are disposable

MD/DOCX/PDF можно удалить и пересобрать из Document IR + Artifact graph + policies без потери authoritative state.
