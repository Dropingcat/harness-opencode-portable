# 03. Entity, Tree and Graph Registry

## A. Document Structure Tree

Typed containment AST:

```text
Document
  Section
    Heading
    Paragraph
      Sentence
        InlineNode
    FigureBlock
    TableBlock
    EquationBlock
    ListBlock
```

Relations: `PARENT_OF`, `NEXT`, `PREVIOUS`, `CONTAINS`.

No epistemic meaning is inferred from containment.

## B. Writing Decomposition DAG

```text
WritingObjective
  -> DocumentRequirement
  -> SectionIntent
  -> ArgumentNeed
  -> DiscourseMoveNeed
  -> ClaimSlot / ArtifactSlot
  -> RealizationUnitNeed
```

A slot may serve several parent needs; therefore DAG, not strict tree.

## C. Discourse Graph

Nodes:
`DiscourseMove`, `SectionIntent`, `ParagraphIntent`, `Transition`, `TopicFocus`.

Canonical roles include:
`BACKGROUND`, `DEFINITION`, `STATE_OF_ART`, `PROBLEM`, `GAP`, `METHOD`, `RESULT`, `COMPARISON`, `INTERPRETATION`, `LIMITATION`, `COUNTERARGUMENT`, `SYNTHESIS`, `LOCAL_CONCLUSION`, `NOVELTY`, `SIGNIFICANCE`.

Relations:
`PREPARES`, `MOTIVATES`, `ELABORATES`, `CONTRASTS`, `QUALIFIES_MOVE`, `LEADS_TO`, `SUMMARIZES`, `ANSWERS`.

## D. Epistemic / Argument Graph

Owned by Researcher. Writer may project:
`Claim`, `Evidence`, `Scope`, `Derivation`, `Assumption`, `Gap`, `Conflict`, `Recommendation`, `Quantity`.

Argument-role projection may add:
`DATA`, `CLAIM`, `WARRANT`, `BACKING`, `QUALIFIER`, `REBUTTAL`.

Writer does not overwrite epistemic state.

## E. Artifact / Symbol Graph

Nodes:
`Quantity`, `Variable`, `Constant`, `Unit`, `Formula`, `Equation`, `Dataset`, `DataColumn`, `Table`, `TableCell`, `Figure`, `FigureSeries`, `Image`, `CodeListing`, `Algorithm`, `Citation`, `Term`, `Definition`, `Footnote`, `ExternalArtifact`.

Relations:
`USES`, `DERIVED_FROM`, `COMPUTED_FROM`, `PLOTS`, `DISPLAYS`, `DEFINES`, `REFERENCES`, `HAS_UNIT`, `HAS_VARIABLE`, `RENDERS_AS`.

## F. Citation / Provenance Graph

```text
SentenceSpan --EXPRESSES--> ClaimRef
ClaimRef --SUPPORTED_BY--> EvidenceRef
EvidenceRef --EXTRACTED_FROM--> SourceVersionRef
CitationMarker --CITES--> SourceRef
Artifact --DERIVED_FROM--> Dataset/Formula/Run
```

## G. Policy / Constraint Graph

Policy families:
`GenrePolicy`, `DomainPolicy`, `RiskPolicy`, `AudiencePolicy`, `InstitutionPolicy`, `JournalPolicy`, `LanguagePolicy`, `StylePolicy`, `NumericPolicy`, `CitationPolicy`, `ReviewPolicy`.

Resolution precedence:

```text
Global < Genre < Domain < Institution/Journal < Project < LocalOverride
```

Conflict must produce explicit `PolicyConflict`; silent last-write-wins forbidden for hard constraints.

## H. Revision / Dependency Graph

Relations:
`DEPENDS_ON`, `INVALIDATES`, `REQUIRES_REVERIFY`, `SUPERSEDES`, `GENERATED_FROM`.

Freshness states:
`FRESH`, `STALE`, `INVALID`, `REBUILDABLE`, `REVERIFY_REQUIRED`.

## I. Execution Graph

Nodes:
`WritingRun`, `Command`, `PlannerRun`, `TemplateInstantiation`, `ModelCall`, `ValidatorRun`, `RepairRun`, `HumanReview`, `Snapshot`, `ExportRun`.

Every state mutation must be attributable to a command/run.
