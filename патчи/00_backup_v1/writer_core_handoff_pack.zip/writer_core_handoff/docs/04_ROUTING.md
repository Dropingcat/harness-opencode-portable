# 04. Typed Routing and State Machines

## 1. Principle

Routing occurs primarily between **entity states and typed operations**, not between free-form agents.

```text
state + policy -> router -> operation -> proposal -> validator -> registry commit
```

## 2. Core routing table

| Input state | Condition | Operation | Output |
|---|---|---|---|
| ClaimSlot | empty | `SelectEligibleClaim` | BindingProposal |
| ClaimSlot | QUALIFIED claim | `PlanQualifier` | Argument constraint |
| ArgumentNeed | unsatisfied | `InstantiateArgumentPattern` | Discourse subgraph |
| ArtifactSlot | missing | `ResolveArtifact` | Artifact binding |
| Artifact | upstream stale | `RebuildArtifact` | new revision |
| RealizationUnit | planned | `RealizeUnit` | draft AST |
| Draft AST | changed | `BackExtractSemantics` | realized semantic set |
| RTT | mismatch | `PlanSemanticRepair` | RepairPlan |
| RTT | pass | `CommitRealization` | committed revision |
| Dependency node | upstream changed | `ComputeImpactClosure` | stale set |
| Citation | unresolved | `ResolveCitation` | citation binding |
| Unit | hard policy violation | `BlockUnit` | BLOCKED issue |

## 3. Operation contract

Every operation has:

```yaml
operation_type:
reads: []
writes: []
preconditions: []
postconditions: []
validator_set: []
reason_codes: []
idempotency_key:
```

LLM operations additionally require:

```yaml
model_assisted:
  input_contract:
  output_schema:
  allowed_semantic_delta:
  forbidden_semantic_delta:
```

## 4. State machine for a realization unit

```text
PLANNED
  -> DRAFTED
  -> OBJECT_VALIDATED
  -> SEMANTIC_EXTRACTED
  -> RTT_PASS
  -> REVIEW_READY
  -> RELEASE_READY
```

Failure branches:

```text
DRAFTED -> RTT_FAIL -> REPAIR_PLANNED -> DRAFTED
ANY -> BLOCKED
ANY -> STALE after dependency invalidation
```

## 5. Router precedence

1. Safety/hard policy gates.
2. Referential integrity.
3. Freshness/dependency gates.
4. Epistemic eligibility.
5. Structural completeness.
6. Semantic realization.
7. Style/optimization.

A style operation may never run in place of failed epistemic/structural validation.
