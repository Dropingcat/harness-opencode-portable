# 05. Writing Contract — Researcher to Writer Boundary

## 1. Why

`allowed/qualified/forbidden` is useful but too lossy for professional writing. Writer needs not only permission to mention a claim, but also the allowed transformation envelope.

## 2. ClaimWritingContract

Required fields:

```yaml
claim_id:
proposition:
claim_kind:
scope:
verifiability:
evidence_state:
evidence_refs: []
writer_eligibility:
modality:
causal_level:
required_qualifiers: []
forbidden_transformations: []
contradiction_refs: []
gap_refs: []
numeric_refs: []
citation_policy:
review_requirement:
```

## 3. WritingSlotContract

A section/paragraph slot declares what it must realize:

```yaml
slot_id:
discourse_role:
required_claims: []
optional_claims: []
forbidden_claims: []
required_artifacts: []
required_relations: []
word_budget:
style_profile_ref:
policy_snapshot_ref:
```

## 4. Allowed semantic delta

Default realization may:

- paraphrase;
- reorder locally if discourse constraints allow;
- add discourse glue with no new factual proposition;
- expand an abbreviation from authoritative term definition;
- render Quantity/Formula/Citation references.

It may not:

- create a new factual claim;
- strengthen causal/modality status;
- drop mandatory qualifier;
- alter scope;
- invent numeric precision;
- merge conflicting claims into false consensus.

## 5. Candidate claims

If generation necessarily creates a new interpretation:

```text
WriterClaimCandidate(PROPOSED)
  -> quarantine from release
  -> Researcher reverify / human adjudication
  -> admitted reference or rejected
```
