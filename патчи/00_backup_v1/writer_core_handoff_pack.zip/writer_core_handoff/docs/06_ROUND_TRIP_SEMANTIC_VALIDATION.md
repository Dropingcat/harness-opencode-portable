# 06. Round-Trip Semantic Validation (RTT)

## 1. Core property

Generation is correct only if the semantic content recovered from output remains within the input Writing Contract.

```text
ContractClaims
  -> Realization
  -> BackExtraction
  -> Alignment
  -> SemanticDiff
```

## 2. Validation levels

### Micro RTT
Sentence/claim realization.

### Meso RTT
Paragraph: required/optional/forbidden claims, qualifiers, numbers, argument relations.

### Macro RTT
Section/document: conclusion support, abstract/body consistency, novelty traceability, global numeric consistency.

## 3. Reason codes

Normative minimum:

- `EXACT`
- `PARAPHRASE_SAFE`
- `SCOPE_SHIFT_MINOR`
- `SCOPE_SHIFT_MAJOR`
- `MODALITY_SHIFT`
- `CAUSALITY_UPGRADE`
- `CAUSALITY_DOWNGRADE`
- `NUMERIC_DRIFT`
- `UNIT_DRIFT`
- `PRECISION_INFLATION`
- `QUALIFIER_DROPPED`
- `NEGATION_FLIP`
- `CONTRADICTION_INTRODUCED`
- `UNAUTHORIZED_CLAIM`
- `REQUIRED_CLAIM_OMITTED`
- `EVIDENCE_ATTRIBUTION_DRIFT`
- `TEMPORAL_SHIFT`
- `ENTITY_SUBSTITUTION`

## 4. Fail closed rules

Hard fail:
`CAUSALITY_UPGRADE`, major scope shift, numeric/unit drift, qualifier drop on QUALIFIED claim, negation flip, unauthorized factual claim, contradiction introduction.

Warning/policy dependent:
minor scope wording ambiguity, optional omission, style-only divergence.

## 5. Alignment output

```yaml
rtt_result:
  contract_id:
  realization_id:
  extracted_claims: []
  alignments:
    - source_claim:
      realized_claim:
      relation: PARAPHRASE_SAFE
      scope_match: MATCH
      modality_match: MATCH
      numeric_match: MATCH
  unauthorized_claims: []
  omitted_required_claims: []
  verdict: PASS
```

## 6. Repair loop

RTT does not ask the same model to "rewrite better" without diagnosis.

```text
SemanticDiff
 -> reason-code-specific RepairPlan
 -> constrained patch
 -> back-extract
 -> RTT again
```

Repair changes the smallest possible span.
