# 08. Agent Roles and Handoff Contracts

Agents are workers over typed operations. They do not own global truth.

## A0. Architecture Guardian

Reads: invariants, schemas, ADRs.
Writes: decision proposals only.
Blocks changes violating boundaries.

## A1. Domain Model Implementer

Implements typed entities, value objects, relation types and migrations.
No prompts, no model calls.

## A2. Writing Decomposition Planner

Input: WritingObjective + contract + policy.
Output: decomposition DAG proposal.
Must not realize prose.

## A3. Discourse/Argument Planner

Input: unsatisfied ArgumentNeed/DiscourseMoveNeed.
Output: typed graph/template instantiation.
Must not invent Researcher claims.

## A4. Artifact Engineer

Owns Quantity/Formula/Dataset/Table/Figure/Code artifact contracts and deterministic validation.

## A5. Realizer

Input: one fully specified RealizationPlan.
Output: structured inline AST + prose spans.
Cannot commit state.

## A6. Semantic Back-Extractor

Input: realization.
Output: extracted claims, scope/modality/causality/numeric mentions.
Independent prompt/model configuration from Realizer where possible.

## A7. RTT Validator

Aligns contract vs back-extraction. Produces machine-readable SemanticDiff. No prose rewrite.

## A8. Repair Planner

Maps RTT reason codes to minimum patch operations.

## A9. Reviewer

Receives review projection: prose + claims + evidence links + artifact refs + validation history.
May propose review decision; policy determines whether human/expert approval is required.

## A10. Export Engineer

Renders Document IR to MD/DOCX/PDF. Cannot alter semantic content.

## Mandatory handoff envelope

```yaml
handoff:
  task_id:
  producer:
  input_versions: []
  outputs: []
  decisions: []
  validations: []
  unresolved: []
  next_operations: []
```
