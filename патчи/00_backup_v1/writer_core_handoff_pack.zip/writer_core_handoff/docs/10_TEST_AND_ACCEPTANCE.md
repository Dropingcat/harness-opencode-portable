# 10. Testing and Acceptance

## Test pyramid

### Domain unit tests
No model calls. Invariants, relations, statuses, policy precedence, dependency closure.

### Golden semantic fixtures
Known WritingContract + realization + expected RTT reason codes.

### Mutation tests
Artificially inject:
- qualifier deletion;
- correlation -> cause;
- 12.5 -> 125;
- μm -> mm;
- population widening;
- negation flip;
- citation reassignment.

Validator must catch mutation.

### Model-assisted reproducibility tests
Model output itself may vary; normalized semantic verdict must remain within acceptance bounds across N runs.

### Integration tests
Researcher fixture -> contract -> plan -> realization -> RTT -> commit -> export.

## Hard acceptance metrics for M1

1. 100% catch rate on curated hard semantic mutations.
2. Zero direct LLM writes to registry in tests.
3. 100% factual spans have claim binding or explicit `UNBOUND_NONFACTUAL` classification.
4. Numeric refs round-trip exactly by ID/value/unit/precision policy.
5. Every committed realization records contract/template/policy/model/validator versions.
6. Failed RTT cannot reach RELEASE_READY.

## Property tests worth adding

- build(export(IR)) does not mutate IR;
- re-running idempotent operation produces no new semantic event;
- dependency closure is monotonic for same graph snapshot;
- safe paraphrase preserves normalized claim tuple;
- changing style profile cannot change claim binding set.
