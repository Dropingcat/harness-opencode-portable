# 11. Migration from Current writer-core / SLAW

## Keep

- stable unit IDs/revisions/snapshots;
- transactions/event log idea;
- provenance links to Researcher;
- object validation with `pint`;
- genre-aware framing;
- Pandoc export direction;
- reviewer workflow;
- claim-table UI idea;
- pattern learning idea.

## Split

Current nested claim model:

```text
DOC/SECTION/PARAGRAPH/ASSERTION/OBJECT
```

becomes:

```text
DocumentTree: DOC/SECTION/PARAGRAPH/SENTENCE/INLINE
Epistemic refs: CLAIM/EVIDENCE/SCOPE
ArtifactGraph: QUANTITY/FORMULA/TABLE/FIGURE/...
DiscourseGraph: INTENT/MOVE/TRANSITION
```

## Replace

`WriterUnit.status` monolith -> orthogonal states.

`writer_context allowed/qualified/forbidden` -> typed Writing Contract while preserving compatibility adapter.

`reference fragment as hint` -> abstract pattern + style profile; raw fragment optional and quarantined from factual provenance.

`similarity scalar` -> quality vector + policy gates.

## Compatibility layer

Provide temporary adapters:

```text
LegacyWriterUnitAdapter
LegacyWriterContextAdapter
LegacySnapshotImporter
```

No legacy class should become a permanent domain superclass.

## Suggested migration order

1. Introduce new IDs and relation enums alongside legacy.
2. Add read-only adapters from legacy state.
3. Generate new IR snapshots in shadow mode.
4. Compare exports and RTT findings.
5. Switch writer commit authority to new registry.
6. Retire legacy mutations.
