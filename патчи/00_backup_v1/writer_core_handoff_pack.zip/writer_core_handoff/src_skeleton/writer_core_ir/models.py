from __future__ import annotations

from enum import StrEnum
from typing import Literal
from pydantic import BaseModel, Field


class Freshness(StrEnum):
    FRESH = "FRESH"
    STALE = "STALE"
    INVALID = "INVALID"
    REBUILDABLE = "REBUILDABLE"
    REVERIFY_REQUIRED = "REVERIFY_REQUIRED"


class ValidationClass(StrEnum):
    STRUCTURAL = "STRUCTURAL"
    SYMBOLIC = "SYMBOLIC"
    RULE_BASED = "RULE_BASED"
    MODEL_ASSISTED = "MODEL_ASSISTED"
    HUMAN = "HUMAN"
    EXPERT = "EXPERT"


class InlineText(BaseModel):
    type: Literal["text"] = "text"
    value: str


class InlineRef(BaseModel):
    type: Literal["claim_ref", "quantity_ref", "formula_ref", "citation_ref", "term_ref", "cross_ref"]
    ref: str
    realization: str | None = None


class DocumentNode(BaseModel):
    id: str
    type: Literal["document", "section", "paragraph", "sentence", "figure", "table", "equation", "list"]
    parent: str | None = None
    order: int = 0
    children: list[str] = Field(default_factory=list)


class ClaimWritingContract(BaseModel):
    claim_id: str
    proposition: str
    claim_kind: str
    writer_eligibility: Literal["ALLOWED", "QUALIFIED", "FORBIDDEN"]
    modality: str | None = None
    causal_level: str | None = None
    required_qualifiers: list[str] = Field(default_factory=list)
    forbidden_transformations: list[str] = Field(default_factory=list)
    evidence_refs: list[str] = Field(default_factory=list)
    numeric_refs: list[str] = Field(default_factory=list)
