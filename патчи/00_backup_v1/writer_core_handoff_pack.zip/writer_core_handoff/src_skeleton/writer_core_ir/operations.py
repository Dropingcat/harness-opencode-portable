from __future__ import annotations

from pydantic import BaseModel, Field


class OperationContract(BaseModel):
    operation_type: str
    reads: list[str] = Field(default_factory=list)
    writes: list[str] = Field(default_factory=list)
    preconditions: list[str] = Field(default_factory=list)
    postconditions: list[str] = Field(default_factory=list)
    validator_set: list[str] = Field(default_factory=list)
    reason_codes: list[str] = Field(default_factory=list)
    idempotency_key: str | None = None
