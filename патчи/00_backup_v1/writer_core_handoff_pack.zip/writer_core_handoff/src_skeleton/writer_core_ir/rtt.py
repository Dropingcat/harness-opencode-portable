from __future__ import annotations

from enum import StrEnum
from pydantic import BaseModel, Field


class RTTReason(StrEnum):
    EXACT = "EXACT"
    PARAPHRASE_SAFE = "PARAPHRASE_SAFE"
    SCOPE_SHIFT_MAJOR = "SCOPE_SHIFT_MAJOR"
    MODALITY_SHIFT = "MODALITY_SHIFT"
    CAUSALITY_UPGRADE = "CAUSALITY_UPGRADE"
    NUMERIC_DRIFT = "NUMERIC_DRIFT"
    UNIT_DRIFT = "UNIT_DRIFT"
    PRECISION_INFLATION = "PRECISION_INFLATION"
    QUALIFIER_DROPPED = "QUALIFIER_DROPPED"
    NEGATION_FLIP = "NEGATION_FLIP"
    UNAUTHORIZED_CLAIM = "UNAUTHORIZED_CLAIM"
    REQUIRED_CLAIM_OMITTED = "REQUIRED_CLAIM_OMITTED"


class RTTResult(BaseModel):
    contract_id: str
    realization_id: str
    verdict: str
    reason_codes: list[RTTReason] = Field(default_factory=list)
    unauthorized_claims: list[str] = Field(default_factory=list)
    omitted_required_claims: list[str] = Field(default_factory=list)
