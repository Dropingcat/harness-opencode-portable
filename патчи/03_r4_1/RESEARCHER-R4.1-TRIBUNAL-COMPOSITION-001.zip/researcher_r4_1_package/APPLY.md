# Apply Researcher R4.1 milestone

Base: `fe57c88312755d01e91a1ff1357481f577b71945`
Final R4.1 HEAD: `7a78a7ccd7c9b26b44698939c333a14f0e91910f`

Preferred continuation path is the full Git bundle in `harness/recovery/`.
For patch-only application, apply the included format-patch stream to a clean checkout at the base and run the acceptance gates in the implementation review.
