# Current architecture state — Writer v1 + Researcher R3.1

This snapshot records the active architecture through Researcher R2.3.3, including adaptive challenge lifecycle, selective invalidation, provenance-triggered reopen and versioned graph-relation lifecycle.

## Peer orchestrators

Writer, Researcher and Coder are peer orchestrators. Each owns its domain reducer and subordinate agents. Cross-domain work is delegated through typed contracts over the shared Job/Attempt/Child runtime rather than by direct mutation of another orchestrator's state.

## Writer

Writer v1 is frozen around typed references/evidence, per-claim evidence selection, tiered cross-language style authority, ProposedClaim handling, structured DraftArtifact, optimistic DOM patching, ChangeLedger, authority binding, semantic round-trip and selective repair.

Rendered claim markers are a checked projection; DOM paragraph claim bindings are authoritative after patch application.

## Researcher

Researcher is based on `scripts/researcher/researcher_core` and remains a full peer orchestrator.

Current planning side:

ResearchRequest -> PlanningDialectic -> ResearchMap -> ResearchCard proposals -> ResearchPatch -> ResearchDOM -> PlanningGate -> persistence/replay.

ResearchDOM is an immutable historical card tree. Cards retain multidimensional metadata such as direction, discipline, question type, method and capability so later tribunal composition can be derived from ancestry rather than reclassified from raw claim text.

`ResearchTraceLink` is the current bridge from planning cards to knowledge entities.

## Universal recursive object-processing principle

The harness treats meaningful units as typed information objects. Examples include objectives, tasks, directions, questions, claims, gaps, evidence spans, paragraphs and computational defects.

The recurring processing pattern is:

Object -> Profile -> Candidate specialists/tools/skills -> Code-owned routing -> Processing -> Artifacts -> Validation -> State transition/new objects.

Decomposition stops when further splitting no longer materially improves executability, verifiability or information gain. This is a practical workflow stopping criterion, not an assertion that Kolmogorov complexity is computable for arbitrary objects.

Specialists, tools and skills are themselves typed entities with individual capability profiles, limitations, cost/availability and historical utility. Routing decisions must be provenance-bearing and versioned so future ranking can learn from actual outcomes.

Three structures remain intentionally distinct:

1. ResearchDOM / task tree: decomposition, execution history and ownership.
2. KnowledgeGraph: semantic and epistemic relationships among claims, evidence, gaps, conflicts, assumptions and artifacts.
3. RoutingHistory: why a specific specialist/tool/skill bundle was chosen for a specific object.

## Current adaptive Researcher loop

Implemented through R2.2:

Gap/Conflict -> ResearchChallenge -> CHALLENGE card -> PlanningDialectic -> executable subtree -> ResolutionAssessment -> resolved/still-open/blocked/reopened lifecycle.

## Next boundary

R2.3 adds negative feedback and historical reopen:

Source/Evidence change -> DependencyImpactAssessment -> stale resolution/relation -> selective revalidation or REOPENED challenge -> new iteration in the same historical branch.

Tribunal/search/live peer delegation remain later layers; R2.3 prepares the dependency semantics they will consume.

## Documentation discipline

From 2026-09-12 each new architectural block must document purpose, authority, contracts, links, current limits, failure behavior, complexity ladder, tests, tech debt and legacy lineage. See `ARCHITECTURE_BLOCK_DOCUMENTATION_STANDARD.md`.

## Researcher R2.3 first-slice status

Negative knowledge feedback is now implemented at deterministic L0/L1: explicit typed dependencies are traversed with bounded impact propagation; redundant evidence causes revalidation without full reopen, sole HARD support can reopen the same historical challenge branch, contextual non-overlap is ignored, and relation-only invalidation can stale a relation without destroying endpoint claims.

New canonical artifacts: `KnowledgeDependency/1.0`, `DependencyImpactAssessment/1.0`, `ChallengeIteration/1.0`.

Current boundary deliberately stops before automatic dependency extraction and SourceCatalog-trigger wiring. Those are tracked as TD-018/TD-019 rather than hidden in the feature.


## R2.3.1 provenance-derived invalidation

Researcher now derives R2.3 dependency records from canonical provenance rather than requiring hand-authored KDP lists. Writer SourceCatalog semantic changes are normalized and, through explicit source identity binding, can drive selective impact/reopen of the same historical challenge branch. BYTE_ONLY changes remain non-semantic and do not reopen knowledge. Shared canonical Source identity remains an explicit next integration debt (TD-021).


## R2.3.3 relation-level truth maintenance

Canonical `GraphEdge` relations are now versioned information objects with ACTIVE/STALE/SUPERSEDED/INVALIDATED lifecycle. Dependency impact may stale an EDG relation without mutating endpoint claims. Relation transitions are optimistic-concurrency checked, replayable through `EDGE_STATE_CHANGED`, visible in service artifacts, and consumed by provenance dependency compilation. Legacy relation event records without state remain backward-compatible as ACTIVE. Dedicated durable relation-history indexing remains TD-022.


## R2 branch freeze and R3 execution boundary

R2.x is now treated as a stable planning/knowledge feedback base. Further R2 development remains possible without blocking execution: relation-history indexing, shared source identity, richer dependency semantics, TMS/ATMS-like justification environments and learned routing are documented in `RESEARCHER_R2_BRANCH_FUTURE_DIRECTIONS.md`.

R3-L1 adds leaf execution while preserving peer boundaries:

`TASK/DELEGATION -> TaskExecutionPlan -> LOCAL Capsule or DelegationRequest -> Job/Child runtime -> TaskExecutionResult -> ResearchCard COMPLETED/BLOCKED`.

Task completion is operational state only. It does not establish a Claim or admit Evidence. Local outputs are untrusted `CapsuleObservation`; peer outputs are artifact references. Typed plans/delegations/results are persisted through the existing SQLite UoW.

R3.1 is now implemented as a typed execution-output admission bridge:

`TaskExecutionResult -> ExecutionAdmissionProposal -> deterministic validator preflight -> existing ClaimRegistry -> ExecutionAdmissionReceipt -> ResearchTraceLink.PRODUCED`.

Successful execution remains operational state only until this admission path accepts typed proposal objects. Local observations can admit explicit ClaimProposal, QuantityProposal, Source and EvidenceSpan objects. Peer artifacts require an explicit typed adapter output; arbitrary artifact interpretation is not allowed. The next boundary is post-admission semantic linking and richer dependency-closed admission, not another registry.

## R3.2 explicit semantic linking

Post-admission execution outputs can now create canonical KnowledgeGraph relations only through explicit typed relation proposals:

`ExecutionAdmissionReceipt -> AdmissionIdentityMap -> SemanticRelationProposal -> deterministic relation gate -> ClaimRegistry(GraphEdge) -> SemanticLinkReceipt -> ResearchTraceLink(PRODUCED -> EDG)`.

No edge is inferred from co-occurrence. L1 enables EVD->CLM SUPPORTS/CONTRADICTS, QTY->CLM QUANTIFIES and CLM->CLM DERIVED_FROM. Claim truth state remains unchanged by edge admission. Cross-admission endpoints and richer relation policy remain future extensions (TD-027/TD-028).

## R3.3 canonical relation assessment

R3.3 separates declared semantic relations from reasoning-eligible relations:

`GraphEdge -> RelationAssessmentProposal -> deterministic relation assessment -> ACCEPTED/QUALIFIED/INCONCLUSIVE/REJECTED -> reasoning eligibility / optional lifecycle projection`.

`GraphEdge.edge_kind`, `GraphEdge.state` and `RelationAssessment.verdict/use_state` are intentionally separate axes. ACCEPTED/QUALIFIED relations may participate in strict reasoning; INCONCLUSIVE relations remain historically ACTIVE but are blocked from semantic use; REJECTED relations may transition to INVALIDATED through the existing R2.3.3 lifecycle reducer. Endpoint Claim/Evidence state is untouched and Claim remains OPEN until later claim-level evidence assessment/Tribunal.

Full pipeline audit confirms execution -> admission -> explicit linking -> relation assessment -> lifecycle projection -> strict dependency compilation -> service artifact. New integration debts TD-029..TD-032 cover mandatory runtime wiring, canonical lifecycle persistence, relation-level challenge feedback and specialized kind-specific validators.


## R3 base closure update — R3.4

R3 is now closed as an L1 base control loop before Tribunal work. The path is:

```text
ResearchDOM TASK
→ execution/delegation
→ typed admission
→ explicit semantic linking
→ relation assessment
→ strict reasoning eligibility
→ ACCEPTED/QUALIFIED: usable relation
→ INCONCLUSIVE: Gap → ResearchChallenge → CHALLENGE → executable TASK
→ REJECTED: relation lifecycle → canonical EDG revision
```

The loop preserves the central authority rule: observations/proposals do not directly mutate epistemic truth. Deterministic reducers/admission boundaries own state transitions.

R3 future work no longer blocks R4: richer relation-kind validators (TD-032), cross-admission endpoint authorization (TD-028), registry-native identity mapping (TD-027), large-graph relation history/index (TD-022), live peer transport (TD-024), and automated repository recovery verification (TD-023).

## R3.5 uncertainty field boundary (2026-09-13)

R3 now ends with an explicit pre-Tribunal uncertainty/work projection:

```text
canonical Claim/Edge/Gap/Conflict/Quantity context
→ RelationAssessment + admitted issues + numeric uncertainty observations
→ UncertaintyComponent[]
→ UncertaintyProfile/1.0 (UPR)
→ ReviewWorkField/1.0 (RWF)
→ R4 TribunalCompositionPolicy
```

R3.5 intentionally does not use a scalar confidence score and does not choose specialist roles. It records uncertainty axis, operational level, blocking status, provenance/reason codes, appropriate assessment methods and completion criteria. R4 receives the RWF plus ResearchDOM dimensions and decides which permanent/dynamic specialists should assess each need.

Implemented L1 axes include numeric measurement, evidence sufficiency, source provenance, scope, method, conflict, derivation, assumption, causality, extrapolation and freshness vocabulary; automatic adapters are currently strongest for relation method/evidence/scope, Gap/Conflict and explicit numeric interval observations. See TD-033/TD-034 for remaining canonical adapters.

## Update 2026-09-13 — R4.1 composition started

R3.5 remains the stable pre-Tribunal boundary. R4.1 now has an implemented deterministic composition compiler and versioned role policy. The compiler maps `ReviewWorkField + ResearchDOM lineage + object profile + policy snapshot` to `TribunalCompositionPlan`; it does not run judges or mutate truth state.

Current R4.1 implementation introduces closed/policy-defined permanent and dynamic roles, AssessmentNeed assignments, evidence-view contracts, allowed capabilities/tools, deterministic synonym-role deduplication, central authority validation, policy hash and composition fingerprint. Full Researcher regression, demo and audit are complete; R4.1 is L1-complete with Git/package/recovery boundary created. The next implementation boundary is R4.2 executable evidence slicing.

Decision lineage for accepted/rejected/open patterns is now maintained in `R4_DECISION_LOG.md` as a required session-migration artifact.
