# R4 Discussion / Decision / Pattern Log

Status: ACTIVE. This file is a session-migration artifact and MUST be updated with each meaningful R4 design change.

## Record format

Each record contains: ID, status, date, question, decision/pattern, rationale, rejected alternatives, consequences, revisit trigger.

Statuses: `ACCEPTED`, `REJECTED`, `OPEN`, `SUPERSEDED`, `EXPERIMENTAL_POLICY`.

---

## R4-D001 — R3/R4 authority boundary

**Status:** ACCEPTED
**Date:** 2026-09-13

**Question:** Should Tribunal determine what is uncertain?

**Decision:** No. `ReviewWorkField` is the R3→R4 boundary. R3 owns characterization of uncertainty and AssessmentNeeds; R4 owns composition of assessors and work contracts.

**Rationale:** prevents Tribunal from inventing its own problem statement and keeps uncertainty analysis separately testable.

**Rejected:** prompt-only Tribunal that first decides what to investigate.

**Revisit:** only if an R4 acceptance test proves RWF structurally insufficient; do not reopen R3.5 for convenience.

## R4-D002 — Composition before dialogue

**Status:** ACCEPTED

**Decision:** R4.1 stops at `TribunalCompositionPlan`. No live judges, attacks, votes or aggregate verdicts.

**Rejected:** port legacy `tribunal-judge.md` directly into the new runtime.

**Reason:** composition must be deterministic/testable before LLM dialogue exists.

## R4-D003 — Closed/versioned role taxonomy

**Status:** ACCEPTED

**Decision:** authoritative roles come from `config/tribunal_composition.yaml`. LLM may later propose missing expertise but cannot create an authoritative role at runtime.

**Rejected:** free-form role names generated from the prompt.

**Consequence:** unsupported role requests fail closed.

## R4-D004 — Permanent panel is policy, not architecture

**Status:** EXPERIMENTAL_POLICY

**Current policy:** Critic + Skeptic + Methodologist + Evidence Auditor.

**Reason:** retains independent meta-review coverage while removing legacy hardcoded five-role prompt.

**Rejected as architecture invariant:** fixed permanent panel compiled into Python.

**Revisit:** after R4.3/R4.4 empirical role utility and duplication data.

## R4-D005 — Advocate handling

**Status:** OPEN / DEFERRED

**Decision for R4.1:** Advocate is not permanent and is not yet instantiated.

**Reason:** without live dialectic, “defend the claim” is not a meaningful composition function and risks systematic confirmation bias.

**Candidate later rule:** activate Advocate conditionally after a typed attack/challenge exists, with bounded evidence and explicit defense contract.

## R4-D006 — Aggregator handling

**Status:** ACCEPTED FOR R4.1

**Decision:** no Aggregator role in composition L1.

**Reason:** there are no typed Tribunal findings to aggregate yet. Majority-vote truth from legacy is explicitly rejected.

**Revisit:** R4/L4 aggregation semantics.

## R4-D007 — AssessmentNeed identity seam

**Status:** ACCEPTED TEMPORARY BRIDGE

**Problem:** R3.5 `AssessmentNeed` has no EntityId although R4 assignments require stable need references.

**Decision:** use R4-local content-addressed `AssessmentNeedRef(ANR-hash, ordinal)` without mutating the completed R3.5 contract.

**Rejected:** silently use list index as identity; opportunistically redesign R3.5 during R4.1.

**Debt:** TD-035 canonical AssessmentNeed identity.

## R4-D008 — Evidence asymmetry belongs to code contract

**Status:** ACCEPTED

**Decision:** `EvidenceViewPolicy` is compiled by R4; role prompts may not widen it.

**Preserved legacy pattern:** asymmetric views reduce correlated failures.

**Rejected legacy mechanism:** `judge_brief.py`/prompt owns final slicing semantics.

## R4-D009 — Fresh-context provenance visibility

**Status:** EXPERIMENTAL_POLICY

**Current policy:** Skeptic `FRESH_CONTEXT`, `include_previous_conclusions=false`, `include_provenance=false`.

**Reason:** strongest independence from prior verdict/source-prestige anchoring at first pass.

**Risk:** hiding provenance may prevent source-quality critique.

**Revisit:** R4.2 should test two-stage fresh pass: blind first pass followed by provenance reveal.

## R4-D010 — Role synonym handling

**Status:** ACCEPTED

**Decision:** roles have `equivalence_group` and `selection_priority`; compiler keeps one canonical candidate per equivalence group.

**Rejected:** string-name dedup only.

## R4-D011 — Lineage routing semantics

**Status:** ACCEPTED L1

**Decision:** role activation uses structural ResearchDOM lineage card kinds and declared dimension/title tags. No unrestricted semantic inference over arbitrary prose.

**Reason:** reproducibility and inspectable routing.

**Future:** typed domain vocabularies / admitted role packs, not opaque learned routing first.

## R4-D012 — Capability/tool authority

**Status:** ACCEPTED

**Decision:** Tribunal role policy may only name capabilities/tools present in central registries. Policy load fails closed otherwise.

**Rejected:** separate Tribunal-only tool registry.

## R4-D013 — Inquiry depth and token budget

**Status:** EXPERIMENTAL_POLICY

**Current values:** depth=2, token budget=6000 per assigned role.

**Meaning in R4.1:** contract metadata only; no execution.

**Revisit:** before R4.3 live inquiry. Values must be calibrated, not fossilized from one fixture.

## R4-D014 — Decision/history tracking

**Status:** ACCEPTED

**Decision:** this log is a required session-handoff artifact. Accepted, rejected, superseded and open patterns must be recorded alongside implementation tracker, tech debt and implementation review.

**Reason:** future sessions need the reasoning lineage, not only the final code state.
