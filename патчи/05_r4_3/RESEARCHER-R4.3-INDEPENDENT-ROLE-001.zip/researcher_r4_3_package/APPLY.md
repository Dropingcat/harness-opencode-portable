# Apply R4.3 Independent Role Execution

Base commit:
`a49291fb81ccd6c7a572444dff5a6bfacb00d093`

Feature commit:
`b435c943d524f430c349bf390ce7b70f7c8968c5`
`researcher: execute independent r4 tribunal roles`

Preferred: use the full repository/recovery bundle from the handoff package.
For patch-only recovery on the exact base:

```bash
git am 0001-researcher-r4.3-independent-role-execution.patch
python scripts/run_researcher_acceptance.py r4
python scripts/run_researcher_acceptance.py gates
```

The full Researcher suite is expected to retain the four known TD-015 Guard/LocalCorpus failures.
