# Apply R4.4 L1 Dialectic Observation

Base commit:
`898f72b4342261f84b8781e4cda98ab30a5baf20`

Feature commit:
`e79e2d59e166a8d39642603f66112d4dc01f0fd3`
`researcher: bound r4 dialectic observation`

Preferred: use the full repository/recovery bundle from the handoff package.
For patch-only recovery on the exact base:

```bash
git am 0001-researcher-r4.4-dialectic-observation.patch
python scripts/run_researcher_acceptance.py r4
python scripts/run_researcher_acceptance.py gates
```

Expected targeted R4 acceptance: 67/67 PASS.
The full Researcher suite is expected to retain the four known TD-015 Guard/LocalCorpus failures.
