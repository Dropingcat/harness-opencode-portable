# R4 Next Phase Plan — after R4.4 L1 dialectic observation

Date: 2026-09-13
Status: R4.4 L1 deterministic observation/stop/escalation substrate implemented; live dialogue execution remains follow-on.

## Completed chain

```text
R3.5 ReviewWorkField
-> R4.1 TribunalCompositionPlan
-> R4.2 role-specific EvidenceSlice
-> R4.3 RoleInstructionPack + InquiryContract
-> independent child Job / Attempt
-> InquiryTurn + ArgumentArtifact
-> R4.4 L1 DialecticObservation
-> deterministic DialecticControlDecision
```

R4.4 L1 also proves a local downstream escape hatch:

```text
blocking EmergentIssue
-> explicit Gap projection
-> existing ResearchChallenge
```

The observer never writes knowledge truth itself.

## R4.4 L1 completed boundary

- [x] process levels separate from confidence/truth;
- [x] multidimensional emergent-issue vocabulary;
- [x] typed interaction-only issue proposals;
- [x] content-addressed novelty/repetition tracking;
- [x] no-progress cutoff;
- [x] evidence-frontier and position-change progress signals;
- [x] depth/turn/Q-A-pair/token boundaries;
- [x] deterministic continuation/escalation actions;
- [x] historical `FIRST_PASS -> CHALLENGE -> Q1/A1 -> Q2/A2` chain validation;
- [x] explicit dialectic issue lifecycle (`RESOLVED` / `STILL_OPEN`) without Claim-truth mutation;
- [x] full-chain turn counting support so questions consume process budget;
- [x] explicit issue -> Gap projection helper;
- [x] E2E `first pass -> Q1/A1 -> Q2(on A1)/A2 -> local research -> ResearchChallenge`;
- [x] portable RoleCard/RoleReference/YAML DOM future direction documented;
- [x] TD-041/042/043 registered;
- [x] R4 acceptance runner includes dialectic tests.

## Validation at current L1 boundary

- R4 targeted: 67/67 PASS.
- Full Researcher: 544 total / 540 PASS / same four TD-015 baseline failures.
- Runtime/capability compiler hashes unchanged; compileall PASS.
- Post-E2E review records the discovered turn-count, issue-lifecycle and fanout defects and their fixes.

## Important sequencing decision

TD-037 live provider binding remains open. Deterministic R4.4 control semantics can be tested over typed fixture artifacts, but **live challenger/questioner/answerer execution must not be claimed complete until provider binding/health is closed**.

This keeps two independent questions separate:

1. does the control algorithm route/stop correctly given valid typed semantic outputs?
2. can production semantic workers reliably produce those outputs under the admitted runtime envelope?

## Next hard boundary — R4.4 L2 disclosure + live bounded dialogue

Minimum goals:

1. Define `DialecticDisclosureContract` that explicitly names which prior Argument/Turn artifacts each role may see.
2. Compile disclosure from existing EvidenceView/prior-review policy; prompts may not widen it.
3. Bind live challenger/questioner/answerer roles through the shared provider-health/capability runtime (TD-037), not a Tribunal-specific provider registry.
4. Add typed question-target contract: every Q1/Q2 points to issue/argument/turn refs and expected closure surface.
5. Execute one real bounded `Q1 -> A1 -> Q2(on A1) -> A2` chain through Job/Attempt.
6. Run a second role-family variation where feasible.
7. Exercise timeout/provider failure/budget exhaustion separately from semantic OPEN/no-progress.
8. Persist/replay the complete historical chain without automatic cross-disclosure.
9. Feed a blocking typed discovery into the existing ResearchChallenge path and verify returned research can resume the same historical dialectic branch rather than starting an unrelated conversation.
10. Post-E2E audit/review only after the live chain runs.

## Dialectic policy questions to resolve in L2/L3

- Which issue kinds trigger a challenger versus direct Q/A?
- When is Advocate/defense activated, and who may request it?
- Does every blocking issue require a FOR/AGAINST pair, or only contested causal/method claims?
- What disclosure does Advocate receive relative to Skeptic/Critic?
- When can a new issue trigger panel recomposition rather than local research?
- How is an answer judged as responsive enough to permit/deny Q2 without making code parse prose semantically?
- How many independent attacks may branch from one argument before fanout becomes wasteful?
- How are returned research artifacts attached back to the exact unresolved issue signature and turn?

These must remain policy/contract decisions, not hidden prompt behavior.

## Later boundary — conditional Advocate / branching argument graph

After one live bounded chain is stable:

```text
independent arguments
-> selected challenge target
-> optional FOR/AGAINST or Advocate defense
-> branching attacks / undercuts / replies
-> bounded local cross-exam chains
-> typed discoveries / research requests
-> explicit convergence/open/escalation control
```

Required properties:

- Advocate is conditional, not a permanent claim defender;
- no majority-vote truth;
- attack/support/undercut/reply edges are versioned/historical;
- one branch may remain OPEN while another closes;
- local research/recomposition affects only the branch that needs it;
- later aggregation summarizes competing justification sets but does not overwrite truth directly.

## Role model growth path

`ROLE_CARD_PORTABLE_DOM_FUTURE.md` now records the future exchange direction:

```text
RoleReference
+ RoleCard
+ RoleVariantCard
+ RoleParameterGraph
+ RoleEvaluationSnapshot
-> PortableRoleDOM YAML
```

This remains non-authoritative future work (TD-041). Domain role packs remain TD-036.

## Explicitly deferred

- TD-036 admitted modular domain role packs;
- TD-038 universal traceability substrate implementation unless required by live dialectic replay;
- TD-039 semantic provenance anonymization;
- TD-041 PortableRoleDOM implementation;
- learned role ranking/effectiveness;
- majority/quorum truth;
- human expert insertion until automated disclosure/inquiry contracts are stable.
