# Apply R4.4 L2a Branching Argument Graph + Conditional Advocate

Base commit:
`2d8f2438540dadab147810a22392d3fa84536e27`

Feature commit:
`910c2f98879278bb391ece71cd92287b8a913137`
`researcher: branch r4 argument graph with conditional advocate`

Preferred: use the full repository/recovery bundle from the handoff package.
For patch-only recovery on the exact base:

```bash
git am 0001-researcher-r4.4-l2a-argument-graph-advocate.patch
python scripts/run_researcher_acceptance.py r4
python scripts/run_researcher_acceptance.py gates
```

Expected targeted R4 acceptance: 76/76 PASS.
The full Researcher suite is expected to retain the four known TD-015 Guard/LocalCorpus failures.
