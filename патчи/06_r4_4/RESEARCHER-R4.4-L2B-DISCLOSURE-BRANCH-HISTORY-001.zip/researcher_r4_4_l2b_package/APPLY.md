# Apply R4.4 L2b Generic Disclosure + Question Targeting + Branch History

Base commit:
`4853230d9515c4333b64dcf1063adf4934487b3c`

Feature commit:
`8fc635160d9f3f90583d5e8e44a3206f4e7366ad`
`researcher: generalize r4 dialectic disclosure`

Preferred: use the full repository/recovery bundle from the handoff package.
For patch-only recovery on the exact base:

```bash
git am 0001-researcher-r4.4-l2b-generic-disclosure-branch-history.patch
python scripts/run_researcher_acceptance.py r4
python scripts/run_researcher_acceptance.py gates
```

Expected targeted R4 acceptance: 82/82 PASS.
The full Researcher suite is expected to retain the four known TD-015 Guard/LocalCorpus failures.
