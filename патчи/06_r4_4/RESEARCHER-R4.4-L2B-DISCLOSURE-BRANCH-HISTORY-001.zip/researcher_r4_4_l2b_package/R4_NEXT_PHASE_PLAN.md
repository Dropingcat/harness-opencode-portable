# R4 Next Phase Plan — after R4.4 L2b generic disclosure + branch history

Date: 2026-09-13
Status: structural bounded-dialectic contracts complete through L2b; live provider execution is next.

## Completed chain

```text
R3.5 ReviewWorkField
-> R4.1 TribunalCompositionPlan
-> R4.2 role-specific EvidenceSlice
-> R4.3 RoleInstructionPack + InquiryContract
-> independent child Job / Attempt
-> InquiryTurn + ArgumentArtifact
-> R4.4 L1 DialecticObservation / ControlDecision
-> R4.4 L2a ArgumentRelation + ArgumentGraphProjection
-> conditional Advocate activation / defense branch
-> R4.4 L2b stable DialecticBranchRef
-> generic DialecticDisclosureContract
-> DialecticQuestionContract
-> branch-scoped DialecticBranchHistory
-> Q1/A1/Q2/A2 structural execution
-> exact Gap/ResearchChallenge branch resume anchor
```

## R4.4 L2b completed boundary

- [x] Shared `tribunal_disclosure.py` owns generic DDC compilation.
- [x] L2a Advocate disclosure reuses generic compiler through compatibility wrapper.
- [x] Disclosure purposes: `CHALLENGE / DIRECT_QUESTION / QUESTION_ON_ANSWER / DEFENSE` plus reserved `CROSS_EXAM`.
- [x] Stable `DialecticBranchRef` separates branch identity from changing AGP revision/head.
- [x] `DialecticDisclosureContract/1.1` explicitly records visible/hidden ARG/IQT/ARL/evidence/target refs.
- [x] `DialecticQuestionContract/1.0` (`DQC-*`) binds questioner, branch, target, closure surface, allowed refs, budget and policy/handbook fingerprints.
- [x] Q2 may target only a newly admitted typed issue surface from A1.
- [x] Question parent IQT must belong to the disclosed branch.
- [x] Answer validation covers both `InquiryTurn.cited_refs` and `ArgumentArtifact` refs/discoveries/requests.
- [x] `DialecticBranchHistory` scopes no-progress, issue lifecycle, Q/A count and token budget to one branch.
- [x] Branch-history checkpoint serialize/restore/fingerprint validation.
- [x] DDC/DQC serialize/restore/integrity validation.
- [x] `DialecticResearchResumeAnchor` binds RCH/GAP to exact branch/issue/history fingerprint.
- [x] Two-branch E2E: branch A executes Q1/A1/Q2/A2 and local research while sibling B stays hidden and history-independent.
- [x] Sibling B can later continue on latest AGP revision without inheriting branch-A counters/issues.
- [x] No Claim/GraphEdge truth mutation and no majority/quorum truth.
- [x] TD-043 acceptance satisfied and closed at L2b.
- [x] TD-045 acceptance satisfied and closed at L2b.

## Important phase-transition rule

Independent first pass remains blind/asymmetric according to the R4.2 EvidenceSlice. Later challenge/cross-exam may reveal additional prior-argument evidence, but only through an explicit fingerprinted DDC.

```text
role prompt / handbook
    cannot widen view

DDC transition
    may explicitly disclose selected prior artifacts for one branch
```

This preserves independent review while still permitting meaningful cross-examination.

## Next hard boundary — R4.4 L3 live bounded dialogue + provider binding

Only now should semantic workers be executed against the structural contracts.

### L3.1 shared provider binding

1. Close or materially narrow TD-037 using the existing logical capability/provider runtime.
2. Bind `RoleInstructionPack + DDC/DQC + EvidenceSlice` to the same Job/Attempt lifecycle already used for R4.3 first-pass workers.
3. Check provider availability/health before attempt start.
4. Persist provider/runtime failure separately from semantic OPEN.
5. Preserve role/tool/evidence authority from policy; provider adapters do not see authority they were not given.

### L3.2 live Q1/A1/Q2/A2 vertical

Run one real branch:

```text
material challenge
-> DDC(DIRECT_QUESTION)
-> DQC(Q1)
-> live questioner Q1
-> live answerer A1
-> deterministic validation/admission
-> DialecticObservation
-> if new admitted surface S:
     DDC(QUESTION_ON_ANSWER)
     -> DQC(Q2 target=S)
     -> live Q2
     -> live A2
-> deterministic observation/control
-> STOP | local research | recomposition | OPEN
```

Requirements:

- [ ] no hidden sibling refs enter prompt/output;
- [ ] Q2 cannot be generated when A1 adds no admitted surface;
- [ ] timeout/provider failure != semantic OPEN;
- [ ] token/turn budgets are branch-local;
- [ ] returned research resumes exact `DialecticResearchResumeAnchor`;
- [ ] one second role-family variation after the first vertical passes;
- [ ] post-E2E review only after real worker execution.

### L3.3 live conditional Advocate

After live Q/A works:

- [ ] execute one real conditional Advocate defense through the same provider/runtime binding;
- [ ] verify `DEFEND / QUALIFY / CONCEDE_LOCAL_POINT / REQUEST_EVIDENCE / OPEN` materialization;
- [ ] verify no evidence widening beyond defense DDC;
- [ ] compare defense usefulness against direct-question path without rewarding unconditional support.

## Advocate policy questions still open

- Which challenge kinds require defense rather than direct Q1?
- Should method/causal undercuts activate defense differently from evidence/provenance attacks?
- When may one root argument receive a second independent defense branch?
- Can a non-Advocate specialist create `DEFENDS` after cross-exam? Graph permits it; activation policy is still Advocate-specific.
- When does `CONCEDE_LOCAL_POINT` resolve an issue versus only qualify the root argument?
- What new surface from defense justifies Q2?
- How will Advocate effectiveness later be calibrated without selecting for unconditional SUPPORT?

These remain explicit policy questions.

## TD-044 / Writer semantic reuse path

Still deferred but preserved:

```text
EmergentIssue + bounded local context
-> Writer-style claim/proposition splitting
-> small local graph + ClaimFacetProposal[]
-> semantic round-trip check
-> equivalence candidates
-> Researcher scope/provenance validation
-> explicit admission
```

Writer remains proposal-only for issue identity and cannot mutate dialogue progress/signatures.

## Role model growth path

`ROLE_CARD_PORTABLE_DOM_FUTURE.md` remains the future exchange direction:

```text
RoleReference
+ RoleCard
+ RoleVariantCard
+ RoleParameterGraph
+ RoleEvaluationSnapshot
-> PortableRoleDOM YAML
```

Portable semantics never carry local runtime authority. Domain role packs remain TD-036.

## Explicitly deferred after L2b

- TD-036 admitted modular domain role packs;
- TD-037 live provider health/binding;
- TD-038 universal cross-layer traceability beyond local branch/resume anchors;
- TD-039 semantic provenance anonymization;
- TD-041 PortableRoleDOM implementation;
- TD-042 live interaction-observer calibration;
- TD-044 semantic issue facet/equivalence implementation;
- learned role ranking/effectiveness;
- majority/quorum truth;
- human expert insertion until automated live bounded inquiry is stable.
