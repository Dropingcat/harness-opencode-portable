# Agent instruction — Full Harness deployment / upgrade

Goal: deploy the integrated Writer + Researcher + Coder Harness without modifying source during acceptance.

1. Verify SHA256 of every archive/bundle.
2. Prefer a fresh extraction of `HARNESS-FULL-WRITER-RESEARCHER-CODER-002.zip`.
3. If only `001.zip` is available, extract it and apply this patch. The patch must report `BASE_001`.
4. If `002.zip` is used, apply this patch only to synchronize final closure governance. It must report `BASE_002` or `ALREADY_FINAL`.
5. Never overlay an unknown older Harness tree. `UNKNOWN_BASE` is a stop condition.
6. Read `DEPLOYMENT_TASK_TRACKER.md` and work through D00–D08.
7. Run `python scripts/run_harness_acceptance.py all`. If one shell invocation is externally time-limited, run `modules` and `gates` separately and preserve both logs.
8. Do not refactor/fix during acceptance. Return the failure trace first.
9. Production OpenCode semantic testing remains a separate gate governed by `REMOTE_OPENCODE_ACCEPTANCE_PROTOCOL.md`.
10. Never include API keys/tokens in returned reports.
