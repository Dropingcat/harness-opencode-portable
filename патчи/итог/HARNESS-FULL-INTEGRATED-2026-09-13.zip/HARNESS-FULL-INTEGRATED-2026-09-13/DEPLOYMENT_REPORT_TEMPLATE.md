# Full Harness deployment report

## Run identity
- Timestamp:
- Agent/operator:
- Host / OS / architecture:
- Python:
- Git:
- OpenCode:
- Target directory:

## Input artifacts
| Artifact | SHA256 | Verified |
|---|---|---|
| code milestone | | |
| upgrade patch | | |
| recovery bundle | | |

## Base / patch
- Detected base:
- Patch status:
- `.release/HARNESS_FULL_RELEASE.json` SHA256:

## Acceptance
| Gate | Result | Count/hash | Log |
|---|---|---|---|
| Writer | | | |
| Researcher | | | |
| Coder | | | |
| R4 focused | | | |
| runtime compiler | | | |
| capability compiler | | | |
| static/compile | | | |

## OpenCode semantic gate
- Executed: YES / NO
- Provider/model:
- Result:
- Trace archives:
- Findings:

## Deviations / failures
For each failure record exact command, exit code, stdout/stderr path, and affected artifact. Never translate runtime/provider failure into scientific `OPEN`.

## Final status
- PASS
- PASS_WITH_FINDINGS
- FAIL_INTEGRITY
- FAIL_REGRESSION
- FAIL_RUNTIME
- FAIL_PROVIDER
- NOT_RUN

Notes:
