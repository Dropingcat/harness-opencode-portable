# Deployment task tracker — Full Harness Writer + Researcher + Coder

Release: `HARNESS-FULL-WRITER-RESEARCHER-CODER-002`
Feature boundary: `68582d3ef527826a4f35d53a362d627220afe9c6`
Canonical closure: `badb5e2526307bf3ebfb4279cfba6a40b7932bf0`

This is a deployment-run worksheet. Do not use it to overwrite the canonical project `IMPLEMENTATION_TRACKER.md`.

## D00 — Integrity / environment
- [ ] Record date/time, operator/agent and deployment path.
- [ ] Record OS / architecture.
- [ ] Record Python version.
- [ ] Record Git version.
- [ ] Record OpenCode version if installed, else `NOT_AVAILABLE`.
- [ ] Verify SHA256 of code milestone.
- [ ] Verify SHA256 of upgrade patch.
- [ ] Verify SHA256 of recovery bundle when supplied.

## D01 — Clean deployment target
- [ ] Use an empty directory or preserve a byte-for-byte backup.
- [ ] Extract `002.zip` (preferred) or `001.zip`.
- [ ] Confirm required roots exist: `scripts/writer`, `scripts/researcher`, `scripts/code-factory`, `scripts/jobs`, `scripts/router`, `scripts/capsules`, `scripts/orchestration`, `agents`, `skills`, `mcp`, `config`, `tests`.
- [ ] Confirm no unrelated local changes are being overwritten.

## D02 — Upgrade / closure synchronization
- [ ] Run `python tools/apply_upgrade_patch.py --target <HARNESS>` from this patch.
- [ ] Record base detection: `BASE_001` / `BASE_002` / `ALREADY_FINAL`.
- [ ] Confirm `.release/HARNESS_FULL_RELEASE.json` exists.
- [ ] Confirm final `IMPLEMENTATION_TRACKER.md`, `TECH_DEBT.md`, `config/tech_debt.json`, `R4_DECISION_LOG.md` exist.
- [ ] Confirm TD-015, TD-051, TD-052 are recorded DONE.

## D03 — Runtime environment
- [ ] Create/use isolated Python environment when practical.
- [ ] Inspect global `PYTHONPATH`; unrelated vendor paths must not silently outrank Harness modules.
- [ ] `requirements-core.txt` reviewed/installed as required.
- [ ] Install `requirements-mcp-doc.txt` only when document-extraction MCP is required.
- [ ] Do not install arbitrary packages merely to hide optional-provider failures.

## D04 — Canonical deterministic acceptance
- [ ] `python scripts/run_harness_acceptance.py modules` PASS.
- [ ] `python scripts/run_harness_acceptance.py gates` PASS.
- [ ] Writer PASS. Reference baseline: 31 tests + 15 subtests.
- [ ] Researcher PASS. Reference baseline: 588/588.
- [ ] Coder PASS. Reference baseline: 5/5.
- [ ] R4 focused PASS when separately run. Reference baseline: 111/111.
- [ ] Runtime compiler policy hash recorded.
- [ ] Capability compiler policy hash recorded.

Expected compiler hashes:
- runtime: `8910fd61122b450212d5bc459cdb52acdc02aa3cf6d87a37c5eaa3778e3cdfef`
- capability: `60105d715f8df50917156216b085f85ee25a2b1deb62947e041bd8537a1a9076`

## D05 — Code-only portability checks
- [ ] Deployment contains no `.git` unless restored intentionally from recovery history.
- [ ] Coder 5/5 still PASS without `.git`.
- [ ] No test requires Harness HEAD merely to prove workspace-snapshot safety.
- [ ] `factory_ctl submit worker` does not use process CWD as implicit Git workspace.

## D06 — Governance continuity
- [ ] Read `FULL_HARNESS_README_FIRST.md`.
- [ ] Read `IMPLEMENTATION_TRACKER.md`.
- [ ] Read `TECH_DEBT.md` and `config/tech_debt.json`.
- [ ] Read `R4_DECISION_LOG.md` before architecture changes.
- [ ] Open debts TD-042/044/046/047/048/049/050 remain visible unless explicitly resolved by later work.

## D07 — Production OpenCode gate, if available
- [ ] Record `opencode --version`.
- [ ] Confirm actual provider health; do not override `NO_HEALTHY_PROVIDER`.
- [ ] Execute `REMOTE_OPENCODE_ACCEPTANCE_PROTOCOL.md` when authorized.
- [ ] Preserve DDC/DQC/ADC → RPB → TEX → PER → IQT/ARG trace artifacts.
- [ ] Return traces without credentials.

## D08 — Report / recovery
- [ ] Fill `DEPLOYMENT_REPORT_TEMPLATE.md`.
- [ ] Preserve stdout/stderr logs.
- [ ] Verify recovery bundle with `git bundle verify` from inside a Git repository when history recovery is needed.
- [ ] Record final state: PASS / PASS_WITH_FINDINGS / FAIL_INTEGRITY / FAIL_REGRESSION / FAIL_RUNTIME / FAIL_PROVIDER.
