# HARNESS FULL INTEGRATED RELEASE — Writer + Researcher + Coder

Date: 2026-09-13
Canonical Git closure: `badb5e2526307bf3ebfb4279cfba6a40b7932bf0`
Code feature hardening: `68582d3ef527826a4f35d53a362d627220afe9c6`

This release contains three deliberately separate deployment paths.

## 1. Fresh deployment — recommended

Use:

`packages/HARNESS-FULL-WRITER-RESEARCHER-CODER-FINAL-2026-09-13.zip`

It is a code-only Git archive from the canonical closure. It intentionally contains no `.git` directory and has been extracted and acceptance-tested in that form.

After extraction:

```bash
python scripts/run_harness_acceptance.py modules
python scripts/run_harness_acceptance.py gates
```

If one combined shell command is not time-limited on your host, `python scripts/run_harness_acceptance.py all` is equivalent.

## 2. Upgrade an older deployed milestone

Use:

`patch/HARNESS-FULL-UPGRADE-001-TO-002-PATCH-001.zip`

The patch supports both old `001` and intermediate `002` code-only milestones, detects the base by fingerprints, fails closed on unknown/modified bases, and is idempotent.

Read `AGENT_DEPLOY_INSTRUCTION.md` and `DEPLOYMENT_TASK_TRACKER.md`.

## 3. Full Git-history recovery

Use:

`recovery/HARNESS-FULL-WRITER-RESEARCHER-CODER-COMPLETE-2026-09-13.bundle`

Example:

```bash
git clone recovery/HARNESS-FULL-WRITER-RESEARCHER-CODER-COMPLETE-2026-09-13.bundle harness-recovered
cd harness-recovered
git checkout master
git rev-parse HEAD
```

Expected HEAD:

`badb5e2526307bf3ebfb4279cfba6a40b7932bf0`

## Governance / continuity

Before architecture changes read `governance/IMPLEMENTATION_TRACKER.md`, `governance/TECH_DEBT.md`, `governance/tech_debt.json` and `governance/R4_DECISION_LOG.md`.

Production semantic OpenCode execution remains a separate external acceptance gate. The deterministic Harness release is not allowed to fake provider availability. See `remote_acceptance/`.
