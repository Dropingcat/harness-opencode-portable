# Recovery instruction

## Verify bundle

Run from any existing Git repository, or clone it directly. `git bundle verify` on some Git versions expects repository context.

```bash
git clone HARNESS-FULL-WRITER-RESEARCHER-CODER-COMPLETE-2026-09-13.bundle harness-recovered
cd harness-recovered
git fsck --full
git rev-parse HEAD
```

Expected HEAD: `badb5e2526307bf3ebfb4279cfba6a40b7932bf0`.

Then run deterministic acceptance:

```bash
python scripts/run_harness_acceptance.py modules
python scripts/run_harness_acceptance.py gates
```

Do not use the upgrade patch on a recovery clone at the expected HEAD. The bundle already contains the final closure.
