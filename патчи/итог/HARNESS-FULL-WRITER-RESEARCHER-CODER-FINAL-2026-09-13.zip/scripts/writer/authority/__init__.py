"""Writer authority boundary helpers."""
