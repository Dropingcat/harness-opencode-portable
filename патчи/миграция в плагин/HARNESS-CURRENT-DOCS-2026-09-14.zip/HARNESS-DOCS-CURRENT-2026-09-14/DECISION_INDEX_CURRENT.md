# Decision Index — Current / Reconciled

## Current plugin/core decisions

- D-P01: OpenCode anti-corruption layer. Only HostAdapter knows OpenCode-specific types.
- D-P02: One generic SemanticExecutionRequest/Result family for Researcher, Writer and Coder.
- D-P03: OpenCode DB is optional diagnostics/forensics, not correctness dependency.
- D-P04: Direct CLI remains explicit legacy fallback only.
- D-P05: Host support requires exact version + live probes + packaged E2E.

## Known decision-ID collision

Historical `R4-D085..R4-D090` and later plugin notes reused the same IDs for different meanings.

**No global renumbering has been applied.**

Proposed context-aware aliases:
- plugin R4-D085 -> R4-D091 Native transport for Desktop;
- plugin R4-D086 -> R4-D092 OpenCode types end at HostAdapter;
- plugin R4-D087 -> R4-D093 common semantic execution boundary;
- plugin R4-D088 -> R4-D094 minimal host tool surface;
- plugin R4-D089 -> R4-D095 reverse channel before production enablement;
- plugin R4-D090 -> R4-D096 capability-certified host support.

These aliases remain PROPOSED until exact checkout search proves R4-D091..096 are free and all references are migrated contextually.

## Rule

Decision identity is `(ID + source document/context)`, never bare number during migration.
