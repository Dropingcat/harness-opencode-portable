# Documentation Maintenance Policy

## Current truth hierarchy

1. Exact code tree + machine registry + executed acceptance log.
2. Current canonical docs in this package.
3. Versioned architecture/review docs tied to a known milestone.
4. Historical trackers/MD.
5. Discussion notes.

A newer document date alone does not silently supersede every older contract.

## Evidence states

Every implementation claim should carry one:
- VERIFIED_RELEASE
- DEPLOYMENT_VERIFIED
- HOSTLESS_REPORTED
- LIVE_CERTIFIED
- DESIGN_ONLY
- RECONCILE_REQUIRED

## Closing tech debt

Required for new closures:
- exact code version/commit/tree;
- command;
- result/log artifact;
- date;
- reviewer/agent;
- acceptance scope;
- remaining related debt.

Missing historical fields remain `unknown`; do not invent them.

## Registry rule

One machine-readable complete TD registry should be canonical. Active/development/closed views are generated projections. Historical files are immutable source records.

## Baseline rule

Never describe:
- integrated code release,
- deployed host,
- plugin hostless P1,
- live OpenCode certification

as a single undifferentiated “current release”.

## Decision ID rule

ID collisions require contextual migration. Global text replacement is forbidden.

## Architecture block standard

Every new block documents:
- goal/non-goals;
- inputs/outputs;
- authority;
- state ownership;
- failure modes;
- fail-closed behavior;
- compatibility;
- tests;
- debt;
- migration/rollback.
