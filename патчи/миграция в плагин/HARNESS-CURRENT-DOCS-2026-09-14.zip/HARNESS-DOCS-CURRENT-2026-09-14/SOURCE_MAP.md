# Source Map

This documentation release was reconciled from:

## Project/release sources
- `FULL_HARNESS_ACCEPTANCE_REPORT.md`
- `FULL_HARNESS_INVENTORY.md`
- `IMPLEMENTATION_TRACKER_FULL_HARNESS.md`
- `TECH_DEBT_FULL_HARNESS.md`
- `TECH_DEBT_FULL_HARNESS.json`
- `R4_DECISION_LOG.md`
- `LOCAL_DEPLOYMENT_STATUS.md`
- `environment.json`
- `capability_preflight.json`

## Native plugin architecture sources
- `OPENCODE_HARNESS_NATIVE_PLUGIN_ARCHITECTURE_V1.md`
- `OPENCODE_HARNESS_PLUGIN_IMPLEMENTATION_PLAN.md`
- `OPENCODE_HARNESS_PLUGIN_RISK_AND_COMPATIBILITY_AUDIT.md`
- `HARNESS_OPENCODE_BOUNDARY_AUDIT_V1.md`
- `HARNESS_NATIVE_PLUGIN_MIGRATION_PLAN_V2.md`
- `HARNESS_PLUGIN_TRACKER_DEBT_DELTA_V2.md`

## Scientific future sources
- `RESEARCHER_FUTURE_HYPOTHESIS_VERIFICATION_CYCLE.md`
- `RESEARCHER_R4_4_FUTURE_RESPONSE_OWNERSHIP_MULTIDISCIPLINARY_REVIEW.md`

## Reconciliation input
- uploaded `Вставленная ​​уценка(6).md`

## External OpenCode references noted by the current project docs
- official plugin documentation;
- official custom tools documentation;
- official SDK/server documentation;
- exact OpenCode v1.18.30 plugin/generated SDK source when compatibility is assessed.

External documentation is compatibility evidence, not proof that our installed host behaves identically. Live probes remain mandatory.
