# Local deployment status

Date: 2026-09-14
Deployment root: `C:\Temp\opencode\harness-deploy`
Source release: `E:\Documents\Документы\doc_Opencode_agern-new\патчи\итог\HARNESS-FULL-WRITER-RESEARCHER-CODER-FINAL-2026-09-13.zip`
Release SHA256: `7d24cd04ea8311d3d028ffa6c2cd25fe5f0c2d18aa69764d1fdce61f23869802`

## Installed local environment

- Python 3.11.15 virtual environment: `.venv`
- pytest 9.1.1
- PyYAML 6.0.3
- pydantic 2.13.5

The release's `requirements-core.txt` intentionally lists only core-factory dependencies and does not install the Writer/Researcher acceptance dependencies above.

## Required environment binding

Before running Harness commands in this deployment, bind paths to the deployment rather than inheriting the development repository:

```powershell
$env:OPENCODE_HARNESS_ROOT = 'C:\Temp\opencode\harness-deploy'
$env:OPENCODE_RUNS_DIR = 'C:\Temp\opencode\harness-deploy\.runs'
$env:WRITER_CORE_ROOT = 'C:\Temp\opencode\harness-deploy\scripts\writer-core'
$env:WRITER_PYTHON = 'C:\Temp\opencode\harness-deploy\.venv\Scripts\python.exe'
```

## Deterministic acceptance completed

- Writer: 31 tests passed; 15 subtests passed.
- Researcher full: 588 tests passed.
- Researcher R4 focused: 111 tests passed.
- Coder: 5 tests passed.
- Named L3/L3B edge suite: 27 tests passed.
- Runtime compiler: PASS; hash `8910fd61122b450212d5bc459cdb52acdc02aa3cf6d87a37c5eaa3778e3cdfef`.
- Capability compiler: PASS; hash `60105d715f8df50917156216b085f85ee25a2b1deb62947e041bd8537a1a9076`.
- Compileall and policy JSON gates: PASS.

## Package comparison

- 2,735 archive files matched byte-for-byte.
- 0 content mismatches.
- 10 reference Markdown paths under `references/workspace-wp/` differ only in ZIP filename decoding on Windows; their extracted counterparts are present. No runtime code is affected.
- `.git` is absent by design in the code-only FINAL distribution. Use `GIT_CEILING_DIRECTORIES=C:\Temp\opencode` when collecting environment data so Git does not incorrectly discover a parent temporary repository.

## External gate / remaining work

Provider `existing.opencode_tribunal_role` is implemented but unavailable:

```text
status=degraded
available=false
implemented=true
detail=missing:opencode
```

Per `REMOTE_OPENCODE_ACCEPTANCE_PROTOCOL.md`, semantic stages T07-T12 must not run here. They remain for a host with an available OpenCode CLI, exact production model ID and host-local credentials. This is `FAIL_RUNTIME`, not scientific `OPEN`.

Generated evidence:

- `environment.json`
- `capability_preflight.json`
