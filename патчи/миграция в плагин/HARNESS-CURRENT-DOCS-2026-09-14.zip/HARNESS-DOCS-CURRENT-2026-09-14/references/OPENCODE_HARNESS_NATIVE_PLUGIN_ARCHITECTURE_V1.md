# OpenCode Native Harness Plugin — Architecture v1

Status: DESIGN / PRE-IMPLEMENTATION
Target initial host: OpenCode 1.18.30
Target Harness: integrated Writer + Researcher + Coder release

## 1. Goal

Build Harness as a normal, installable, maintainable OpenCode integration rather than a one-off script or Desktop IPC workaround.

The plugin must:

- load through OpenCode's supported plugin mechanism;
- expose a small stable Harness-facing tool surface to the primary OpenCode agent;
- keep the existing Python Harness as the authoritative routing/state/validation core;
- let Harness request semantic execution from the already running OpenCode runtime;
- support Writer, Researcher, Coder and Tribunal without creating a second scheduler;
- preserve Job/Attempt, RPB/TEX/PER, provenance and fail-closed semantics;
- be versioned independently and tested against explicit OpenCode versions;
- be installable both online (npm plugin) and offline (release bundle);
- support upgrades, diagnostics, recovery and backward-compatible migrations.

## 2. Non-goals

The plugin is not:

- a rewrite of Harness in TypeScript;
- a replacement for Researcher/Writer/Coder contracts;
- an alternate truth/admission layer;
- a Desktop IPC reverse-engineering shim;
- a hidden source of API credentials;
- a second Job scheduler;
- a place to move policy that already belongs to the Harness core.

## 3. Official OpenCode host surface we can rely on initially

For OpenCode v1.18.30 the plugin API gives the plugin:

- `client` — an OpenCode SDK client;
- `project`;
- `directory`;
- `worktree`;
- `serverUrl`;
- Bun shell `$`.

The plugin hook type contains `dispose`, `event`, `config`, `tool`, `chat.*`, `tool.execute.*`, `shell.env` and experimental transforms.

Custom tool context contains:

- `sessionID`;
- `messageID`;
- `agent`;
- `directory`;
- `worktree`;
- `abort`;
- `metadata(...)`;
- `ask(...)`.

OpenCode supports project plugins under `.opencode/plugins/`, global plugins under the user config directory, and npm plugins referenced from `opencode.json`. npm plugins are installed automatically by OpenCode using Bun.

## 4. Audit of the legacy Harness OpenCode plugin

The existing `plugins/tool-skill-contract-router.ts` must be treated as legacy and removed from the authoritative path.

It currently tries to:

- mutate tool descriptions;
- run a guard after untrusted tools;
- inject routing hints into the system context.

Against OpenCode v1.18.30 its hook assumptions are mismatched:

1. `tool.definition` officially receives `input.toolID`; the legacy plugin searches nested `tool.name` / output name fields.
2. `tool.execute.after` officially receives `input.tool` as a string; the legacy plugin searches `input.tool.name` or `input.name`.
3. `experimental.chat.system.transform` officially exposes `output.system` as `string[]`; the legacy plugin handles a string or `output.messages`.
4. Its routing hint attempts to infer request text from a system-transform input that does not contain the user messages expected by the code.
5. It uses synchronous subprocess execution for guard work inside a hook.

This is consistent with old TD-002 and explains why the old plugin should not be incrementally promoted into the new production bridge.

Migration decision:

- preserve its policy data in compiled Harness snapshots;
- move routing and guard authority into Harness core;
- deprecate the old OpenCode hook implementation;
- do not load old and new plugins simultaneously.

## 5. Proposed product architecture

```text
OpenCode Desktop / TUI / Server
          │
          │ supported plugin API
          ▼
@harness/opencode-plugin
          │
          ├── OpenCode Host Adapter
          ├── Tool Frontend
          ├── Bridge Supervisor
          ├── Semantic Execution Adapter
          ├── Host Compatibility Probe
          ├── Trace / Logging Adapter
          │
          │ bidirectional JSON-RPC over stdio
          ▼
Harness Bridge Daemon (Python)
          │
          ├── existing Router
          ├── Job / Attempt runtime
          ├── Writer
          ├── Researcher
          ├── Coder
          ├── Tribunal / RPB / TEX / PER
          └── existing reducers / validators
```

The TypeScript plugin is an adapter. Python Harness remains the authority.

## 6. Why the bridge must be bidirectional

A one-way custom tool is insufficient.

Initial direction:

```text
OpenCode primary agent
  -> harness_run
  -> Harness core
```

During the same Harness Job, Researcher may decide it needs a semantic specialist:

```text
Harness core
  -> semantic.execute
  -> OpenCode plugin
  -> OpenCode child session
  -> specialist response
  -> Harness core
```

Therefore the bridge protocol must allow both endpoints to initiate RPC requests while another request remains in progress.

## 7. Bridge transport

### v1 transport

Use JSON-RPC 2.0 semantics over newline-delimited JSON (NDJSON) on a child process stdio channel.

Plugin process:

```text
spawn python -m harness_bridge.daemon
stdin  <-> stdout
stderr -> structured diagnostic capture
```

Reasons:

- no TCP port discovery;
- no firewall configuration;
- no new authentication secret;
- process lifecycle naturally follows OpenCode plugin lifecycle;
- works on Windows/Linux/macOS;
- supports full-duplex requests;
- easy to fake in tests.

Do not use `spawnSync`.

### Transport abstraction

Implement a `BridgeTransport` interface from day one so later versions can add:

- stdio (default);
- named pipe / Unix socket;
- localhost HTTP/WebSocket;
- remote Harness service.

Protocol semantics must not depend on transport.

## 8. Bridge protocol contracts

Protocol family: `harness-bridge-rpc/1.x`.

All requests include:

```text
rpc_id
protocol_version
trace_id
project_id
open_code_session_id?
harness_job_id?
timestamp
```

Core methods:

```text
bridge.hello
bridge.health
bridge.shutdown
harness.run
harness.resume
harness.cancel
semantic.execute       # reverse request: Harness -> plugin
semantic.cancel
host.describe
```

### Handshake

Plugin -> daemon:

```json
{
  "method": "bridge.hello",
  "params": {
    "plugin_version": "0.1.0",
    "protocol_versions": ["1.0"],
    "opencode_version": "1.18.30",
    "project": {},
    "directory": "...",
    "worktree": "...",
    "host_features": {}
  }
}
```

Daemon replies with:

```text
core_version
core_commit
accepted_protocol_version
policy hashes
supported execution contracts
required host features
warnings
```

Protocol incompatibility is fail-closed.

## 9. OpenCode-facing tool surface

Keep it intentionally small.

### `harness_run`

Primary entry point.

Input direction:

```text
request
mode? = auto | research | write | code
resume_token?
```

The user-facing model does not choose Tribunal roles, providers, evidence slices or internal tools.

### `harness_status`

Read-only diagnostic tool.

Returns:

```text
plugin version
core version
OpenCode version
bridge state
policy hashes
active jobs
provider readiness
compatibility status
```

### Optional later `harness_resume`

Only if resume semantics cannot remain inside `harness_run` without making the schema ambiguous.

Prefix every tool with `harness_` to prevent built-in collisions.

## 10. Semantic execution adapter

The plugin receives reverse RPC `semantic.execute` from Harness.

The request should contain an immutable semantic execution envelope, not arbitrary "please ask the model" text.

Minimum fields:

```text
execution_id
parent_session_id
role_id
role_kind
execution_contract
instruction_fingerprint
TEX / bounded material
expected output contract
model policy
timeout
allowed execution mode
```

The plugin then:

1. resolves host compatibility and model policy;
2. creates a child OpenCode session with `parentID` when supported;
3. applies an internal safe semantic-worker permission profile;
4. sends the bounded prompt through the OpenCode SDK client;
5. captures session/model/runtime identifiers;
6. returns an execution receipt to Harness.

Harness, not the plugin, decides whether the semantic output is admissible.

## 11. Internal semantic worker isolation

This is a hard requirement.

A semantic child session must not see `harness_run` as an available recursive orchestration tool. Otherwise:

```text
Harness -> semantic worker -> harness_run -> Harness -> semantic worker ...
```

is an entirely predictable recursion failure.

Use one of these host-supported mechanisms, selected by compatibility profile:

- session-level permission rules denying tools;
- a hidden internal OpenCode agent with default-deny permissions;
- explicit tool disable map where supported.

The internal worker should normally be no-tool / read-no-side-effects. Any role needing tools must receive them explicitly from Harness policy rather than inheriting the primary agent's capabilities.

## 12. Role vs OpenCode agent

Do not identify Harness semantic roles with OpenCode agents.

```text
Harness role            OpenCode runtime profile
------------            ------------------------
xrd_specialist    ->     generic internal worker + role instruction
skeptic           ->     generic internal worker + role instruction
advocate          ->     generic internal worker + role instruction
```

The scientific role remains a Harness semantic object.

OpenCode agent/model/session are execution resources.

## 13. Structured output policy

OpenCode supports JSON-schema output in its SDK/schema surface, but production history shows structured-output regressions and model-specific failures.

Therefore structured output is a host capability, not an invariant.

Policy modes:

```text
auto       use host JSON-schema output when compatibility profile permits
strict     fail if host/model cannot supply structured output
off        request text JSON and validate only in Harness
```

Even when host JSON-schema validation succeeds, Harness revalidates the response against its canonical contract and grounding rules.

Never equate:

```text
OpenCode schema-valid == Harness semantically admissible
```

Any fallback mode must be explicit and recorded in provider/execution lineage. No silent fallback.

## 14. Lifecycle

### Startup

```text
OpenCode loads plugin
 -> read Harness config
 -> get OpenCode host version
 -> build HostCapabilitySnapshot
 -> spawn bridge daemon
 -> handshake
 -> mark READY or DEGRADED
 -> expose harness tools
```

Startup must be fast. Long acceptance work must not run synchronously during plugin initialization.

### Tool request

```text
harness_run
 -> create correlation id
 -> RPC harness.run
 -> core routes Writer/Researcher/Coder
 -> optional reverse semantic.execute calls
 -> core returns result/artifact refs
 -> plugin returns ToolResult
```

### Shutdown

Use plugin `dispose`:

```text
stop accepting new work
cancel/finish bridge requests per policy
send bridge.shutdown
gracefully terminate daemon
force kill after timeout
flush trace
```

OpenCode v1.18.30 exposes a `dispose` plugin hook, so this lifecycle can be implemented through a supported surface.

## 15. Cancellation and timeouts

OpenCode custom tool context contains an `AbortSignal`.

Map it:

```text
OpenCode abort
 -> harness.cancel(job)
 -> cancel child semantic sessions
 -> Job/Attempt terminal state
 -> PER TIMED_OUT / FAILED / CANCELLED as appropriate
```

Do not collapse runtime cancellation into epistemic `OPEN`.

Timeouts must be layered:

```text
plugin tool timeout
bridge request timeout
Harness Job timeout
semantic child session timeout
provider timeout
```

Each timeout source must be recorded separately.

## 16. Concurrency model

The bridge must multiplex requests by `rpc_id` and never assume one active request.

Required v1 scenarios:

- two concurrent primary OpenCode sessions;
- one Harness Job with two independent semantic branches;
- one cancelled branch while another remains active;
- child semantic reply arriving while `harness.run` is still waiting;
- plugin shutdown with active jobs.

Do not implement a new scheduler. Harness Job/Attempt remains authoritative.

## 17. State and persistence

Plugin process state is disposable.

Persist authoritative state only through existing Harness storage/run artifacts.

Plugin keeps transient maps only:

```text
OpenCode session -> Harness Job
semantic execution -> child OpenCode session
rpc_id -> pending Promise
```

After plugin restart, recovery uses Harness Job state and explicit resume contracts, not reconstruction from in-memory maps.

## 18. Security model

### Credentials

Provider/API credentials remain inside OpenCode. The bridge never asks Harness core to store them.

### Environment

Spawn Harness daemon with an allowlisted environment. Do not pass the entire host process environment blindly.

Allow examples:

```text
PATH
PYTHONPATH only when explicitly configured
HARNESS_ROOT
HARNESS_RUNS_DIR
locale/temp variables
```

Do not export provider tokens unless a separate capability explicitly requires them.

### Paths

Use `context.directory` and `context.worktree`; do not infer project authority from process cwd.

### Permissions

Use OpenCode permissions for the user-visible `harness_*` tools and Harness internal permission/admission policy for actual side effects.

## 19. Observability

Use `client.app.log()` for host-visible structured logs.

Do not depend on `console.log`.

Every execution should record:

```text
plugin_version
bridge_protocol_version
core_version / commit
OpenCode version
parent session id
worker session id
model provider/id
RPB/TEX fingerprints
execution mode
runtime outcome
latency
error class
```

Correctness must not depend on generic plugin lifecycle hooks. In particular, do not use `tool.execute.after` as an authoritative guard gate.

## 20. Host compatibility architecture

Create `HostCapabilitySnapshot` rather than checking version strings alone.

Example:

```text
host_version
plugin_api_present
plugin_tool_registration
plugin_dispose
sdk_session_create
child_session_parent_id
sdk_session_prompt
structured_output
session_abort
permission_rules
server_tool_ids_probe
```

Version gives the expected profile; live probes verify it.

### Initial supported matrix

```text
OpenCode 1.18.30 = first production-certified host
current stable   = test candidate, not implicitly supported
OpenCode dev     = CI canary only
```

Do not claim a version supported until full plugin E2E passes on it.

## 21. Upstream fragility we must design around

Observed upstream problem classes include:

- declared hooks that were not invoked in some versions;
- external plugin `tool` registration regressions;
- plugin hook error/order interactions;
- structured-output retry behavior not matching the exposed schema;
- structured-output/model compatibility failures.

Therefore:

- minimal hook surface;
- no authority on observational hooks;
- compatibility acceptance per host version;
- Harness-side validation remains canonical;
- explicit fallback policy;
- package releases pin a tested OpenCode compatibility matrix.

## 22. Packaging

Recommended repository structure:

```text
packages/
  opencode-plugin/
    src/
      index.ts
      host/
      bridge/
      tools/
      semantic/
      compat/
      logging/
    tests/
    package.json

scripts/bridge/
  harnessd.py

shared/bridge_protocol/
  schemas/
  fixtures/

compatibility/
  opencode.json

release/
  install.ps1
  install.sh
  doctor.ps1
  doctor.sh
```

### Online install

Canonical production package:

```text
@harness/opencode-plugin@X.Y.Z
```

referenced from `opencode.json`.

### Offline/bundle install

Ship:

```text
plugin npm tarball or compiled bundle
Harness core
Python wheelhouse / locked dependencies
installer
compatibility matrix
schemas
checksums
SBOM
release manifest
```

Runtime plugin startup must not secretly install Python packages. Installation/update is an explicit deployment action.

## 23. Versioning

Version four things separately:

```text
Plugin SemVer             e.g. 0.1.0
Harness Core version      existing release/commit
Bridge protocol           1.0
Individual contracts      existing DQC/TEX/PER/etc versions
```

A plugin update must not silently change canonical Harness contract semantics.

Handshake determines compatibility.

Suggested compatibility rule:

```text
protocol major mismatch -> BLOCK
protocol minor mismatch -> negotiate common features
plugin/core unsupported pair -> BLOCK
OpenCode outside certified matrix -> DEGRADED_UNCERTIFIED by default
```

## 24. Configuration

Canonical config hierarchy:

```text
HARNESS_CONFIG env path
.opencode/harness.json
~/.config/opencode/harness.json
built-in safe defaults
```

No secrets in this file.

Example:

```json
{
  "schema": "harness-opencode-config/1.0",
  "harnessRoot": "C:/.../harness",
  "python": "C:/.../.venv/Scripts/python.exe",
  "runsDir": "C:/.../.runs",
  "bridge": {
    "transport": "stdio",
    "startupTimeoutMs": 10000
  },
  "semantic": {
    "modelPolicy": "inherit_parent",
    "structuredOutput": "auto",
    "workerProfile": "no_tools"
  },
  "logging": {
    "level": "info"
  }
}
```

## 25. Installation / upgrade behavior

Installer responsibilities:

- discover OpenCode config/project location;
- verify supported OpenCode host version;
- install plugin bundle/package;
- install/validate Harness Python environment;
- write Harness config without secrets;
- disable/remove legacy `tool-skill-contract-router.ts` from active plugin set;
- run `harness doctor`;
- run plugin smoke acceptance;
- create rollback metadata.

Never rewrite JSONC with a naive comment stripper. Use a real JSONC parser or an additive local-plugin installation path.

## 26. Doctor command

A first-class diagnostic is mandatory.

`harness doctor --opencode` should report:

```text
OpenCode version
plugin loaded
plugin version
custom tool visible
bridge daemon executable
bridge handshake
protocol negotiated
Harness core version
policy hashes
semantic client/session API
model/provider availability
structured-output capability
legacy plugin conflict
ready/degraded/blocking reasons
```

Output both human text and JSON.

## 27. Acceptance ladder

### L0 package/static

- TypeScript build/typecheck.
- Python compileall.
- JSON Schema validation.
- package integrity/checksum.

### L1 bridge contract

- TS <-> Python handshake.
- bidirectional request/response.
- concurrent requests.
- cancellation.
- daemon crash/restart.
- protocol mismatch.

### L2 fake OpenCode host

- create child session.
- prompt response.
- provider errors.
- structured-output success/failure.
- abort.

### L3 real OpenCode host smoke

- plugin loads.
- `harness_status` is present.
- `harness_run` is visible and callable.
- legacy plugin not active.
- bridge READY.

### L4 Harness vertical

```text
primary session
 -> harness_run
 -> Router
 -> Researcher
 -> deterministic result
 -> return to OpenCode
```

### L5 semantic vertical

```text
harness_run
 -> Researcher
 -> RPB/TEX
 -> reverse semantic.execute
 -> OpenCode child session
 -> answer
 -> PER/IQT/ARG
 -> graph admission
```

### L6 Tribunal

Q1/A1 -> Q2/A2 -> conditional Advocate -> ResearchChallenge/stop.

### L7 Writer/Coder semantic paths

Reuse the same plugin semantic transport rather than adding role-specific transports.

### L8 concurrency/recovery

- two parent sessions;
- restart plugin;
- resume Harness job;
- cancel one of several branches;
- upgrade plugin between runs.

## 28. Release policy

No plugin release is `stable` unless:

- exact OpenCode versions in compatibility matrix have passed L0-L8 required subset;
- upgrade from previous plugin version passes;
- protocol compatibility fixtures pass;
- clean installation and uninstall/rollback pass;
- packaged artifact is tested after extraction/install, not only repository checkout.

Release channels:

```text
alpha   architecture/protocol may move
beta    protocol frozen, host matrix expanding
stable  certified host matrix + migration support
```

## 29. Proposed migration from current Harness

Phase P0 — freeze and document legacy plugin.

Phase P1 — implement bridge protocol and daemon with fake host.

Phase P2 — implement OpenCode plugin host adapter and `harness_status` only.

Phase P3 — add `harness_run` and deterministic Harness vertical.

Phase P4 — add reverse `semantic.execute` via OpenCode SDK.

Phase P5 — real Desktop 1.18.30 Tribunal trace.

Phase P6 — Writer/Coder use same semantic transport.

Phase P7 — package, installer, doctor, upgrade/rollback.

Phase P8 — certify additional OpenCode versions.

Do not attempt to port all existing OpenCode routing hints/guards into P1-P2.

## 30. Core architectural invariant

The final relationship should be:

```text
OpenCode owns model execution and user-facing session runtime.
Harness owns orchestration, research state, validation and authority.
Plugin owns transport and host integration only.
```

That separation is the condition for the module to remain maintainable as both OpenCode and Harness evolve.

## References reviewed

Official OpenCode documentation and exact v1.18.30 repository sources were reviewed, including:

- Plugins documentation.
- Custom Tools documentation.
- SDK documentation.
- Server/OpenAPI documentation.
- Agents and Permissions documentation.
- `packages/plugin/src/index.ts` at tag `v1.18.30`.
- `packages/plugin/src/tool.ts` at tag `v1.18.30`.
- OpenCode release `v1.18.30`.

Upstream issue classes reviewed for compatibility risk:

- external plugin tool registration regression;
- `tool.execute.after` invocation regression;
- plugin ordering/error propagation;
- structured-output retry and model compatibility regressions.
