# OpenCode Harness Native Plugin — Implementation Plan

## Workstream P0 — architecture freeze and legacy isolation

Deliverables:

- architecture document;
- compatibility/risk audit;
- decision: legacy `tool-skill-contract-router.ts` deprecated;
- TD entries for provider readiness, transport matrix, protocol and legacy-plugin retirement;
- no runtime behavior changed yet.

Acceptance:

- old plugin functions mapped to their new owners;
- no functionality silently dropped.

## Workstream P1 — bridge protocol and daemon

Implement:

- `harness-bridge-rpc/1.0` schemas;
- TypeScript RPC peer;
- Python RPC peer;
- async stdio framing;
- bidirectional requests;
- handshake;
- cancellation;
- health;
- concurrency;
- graceful shutdown.

No OpenCode dependency yet.

Acceptance:

- TS <-> Python fake E2E;
- 100 concurrent request correlation test;
- reverse request while original request is pending;
- cancellation and crash tests;
- protocol major mismatch blocks.

## Workstream P2 — OpenCode host adapter + status-only plugin

Implement npm/local plugin package:

- config loader;
- HostCapabilitySnapshot;
- bridge supervisor;
- `harness_status` tool;
- structured logging;
- `dispose` lifecycle.

Do not expose `harness_run` yet.

Acceptance on OpenCode 1.18.30 Desktop:

- plugin auto-loads;
- tool is actually visible;
- status reports exact host/plugin/core versions;
- daemon starts/stops correctly;
- legacy plugin conflict is detected.

## Workstream P3 — deterministic `harness_run`

Add user-visible orchestration tool.

Flow:

```text
OpenCode -> harness_run -> RPC -> Harness router -> deterministic path -> result
```

No semantic callback yet.

Acceptance:

- research routing;
- writing routing;
- coding routing;
- invalid mode;
- user abort;
- two concurrent OpenCode sessions;
- project/worktree binding.

## Workstream P4 — reverse semantic execution

Implement `semantic.execute` callback using OpenCode SDK client.

Required:

- child session creation;
- parent session linkage;
- safe internal worker permissions;
- model resolution policy;
- prompt execution;
- receipt mapping;
- session abort mapping;
- explicit structured-output mode.

Acceptance:

- fake SDK tests;
- real one-turn semantic execution;
- no recursive `harness_*` access;
- provider auth failure classified as runtime failure;
- timeout distinct from epistemic OPEN.

## Workstream P5 — Tribunal production trace

Use existing RPB/TEX/PER path.

Required E2E:

```text
primary session
 -> harness_run
 -> Researcher
 -> Q1
 -> semantic.execute
 -> A1
 -> grounding
 -> graph admission
 -> Q2 if new issue
 -> A2
 -> conditional Advocate
```

Repeat at least three times for variability.

## Workstream P6 — shared Writer/Coder semantic transport

No new role-specific provider transport.

Use same OpenCode plugin semantic adapter for:

- Writer semantic drafting/repair where appropriate;
- Coder semantic worker/reviewer where appropriate;
- Researcher Tribunal roles.

Authority stays module-specific.

## Workstream P7 — packaging and operations

Produce:

- npm package;
- local/offline plugin bundle;
- Python core/bridge package;
- PowerShell and shell installers;
- doctor command;
- uninstall/rollback;
- compatibility matrix;
- checksums/SBOM;
- upgrade tests.

## Workstream P8 — host certification lab

Test each target OpenCode release/platform.

Initial matrix:

```text
OpenCode 1.18.30 / Windows AMD64 / Desktop = mandatory
OpenCode current stable / Linux AMD64 = next
OpenCode current stable / Windows = next
OpenCode dev = canary only
```

## Proposed implementation directory layout

```text
packages/opencode-plugin/
  package.json
  tsconfig.json
  src/
    index.ts
    config.ts
    host_adapter.ts
    compatibility.ts
    logging.ts
    tools/
      status.ts
      run.ts
    bridge/
      peer.ts
      framing.ts
      supervisor.ts
    semantic/
      executor.ts
      model_policy.ts
      receipt.ts
  tests/

scripts/bridge/
  harnessd.py
  protocol.py
  handlers.py

shared/bridge_protocol/
  harness-bridge-rpc-1.0.schema.json
  semantic-execute-1.0.schema.json
  host-capability-snapshot-1.0.schema.json
  fixtures/

compatibility/opencode/
  1.18.30.json

scripts/plugin/
  doctor.py
  install.ps1
  install.sh
  uninstall.ps1
  uninstall.sh
```

## New acceptance commands target

```text
python scripts/run_plugin_acceptance.py bridge
python scripts/run_plugin_acceptance.py package
python scripts/run_plugin_acceptance.py opencode-smoke
python scripts/run_plugin_acceptance.py semantic
python scripts/run_plugin_acceptance.py tribunal
python scripts/run_plugin_acceptance.py all
```

## Stop conditions

Stop and do not continue to the next phase when:

- plugin tool is not visible in the certified host;
- protocol/version handshake is ambiguous;
- semantic child session can recursively invoke Harness;
- host credentials leak to Harness daemon;
- cancellation cannot be propagated deterministically;
- runtime failures become semantic OPEN;
- the implementation requires private Desktop IPC.
