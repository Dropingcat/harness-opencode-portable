# OpenCode Harness Plugin — Risk and Compatibility Audit

Status: DESIGN INPUT
Initial host target: OpenCode 1.18.30

## A. Risk principle

The plugin API is useful and sufficiently capable, but it is not stable enough to treat TypeScript declarations as proof of runtime behavior.

Support must therefore mean:

```text
source says feature exists
+ runtime probe says it exists
+ packaged E2E proves it works
```

not merely:

```text
interface contains field
```

## B. Major risks

| Risk | Failure mode | Design response | Release gate |
|---|---|---|---|
| Plugin tool registration drift | plugin loads but `harness_run` invisible | compatibility smoke + tool visibility probe; optional alternate frontend later | L3 |
| Hook declared but not invoked | guard/trace silently absent | no correctness depends on generic after/event hooks | L3/L5 |
| Hook order/error coupling | another plugin error prevents our observational hook | minimal hooks; catch own non-blocking errors; no correctness in observational hooks | multi-plugin test |
| Structured output regression | valid request fails or retry behavior differs | optional capability; Harness revalidation; explicit fallback policy | L5 |
| Model-specific structured output | one model rejects format/tool-choice behavior | per-model capability record; no global assumption | model matrix |
| OpenCode version API drift | session/client method shape changes | host adapter + feature probes + certified matrix | every release |
| Plugin/core version mismatch | subtle protocol corruption | handshake + protocol semver + fail closed | L1 |
| Recursive Harness invocation | semantic worker calls `harness_run` | internal no-tool/default-deny worker profile | L5 |
| Plugin reload during job | transient in-memory map lost | Harness persistence authoritative; explicit resume | L8 |
| Multiple projects/sessions | cross-project routing leakage | plugin instance/project scoped bridge; explicit IDs | L8 |
| Windows subprocess behavior | quoting/encoding/termination defects | async spawn; explicit argv; UTF-8 JSON; Windows E2E | platform matrix |
| Secret leakage | provider keys inherited by Python child | environment allowlist; credentials stay in OpenCode | security gate |
| Legacy plugin coexistence | duplicate routing/guard behavior | installer detects and disables legacy plugin | install gate |
| cwd authority confusion | wrong project files/state | use OpenCode `directory/worktree`, never implicit process cwd | L3 |

## C. Exact v1.18.30 surface relevant to us

Confirmed in tag `v1.18.30`:

- PluginInput includes `client`, `project`, `directory`, `worktree`, `serverUrl`, `$`.
- Plugin configuration type supports plugin specifiers and plugin options.
- Hooks include `dispose`, `event`, `config`, `tool`, `chat.*`, `tool.execute.before/after`, `shell.env`, experimental transforms.
- ToolContext includes `sessionID`, `messageID`, `agent`, `directory`, `worktree`, `abort`, `metadata`, `ask`.
- JSON-schema output types exist in the generated SDK/schema types.
- Session objects have `parentID` and model/provider metadata needed for trace.

These facts make a native bridge feasible without Desktop private IPC.

## D. Legacy plugin incompatibility

The current Harness `tool-skill-contract-router.ts` must not be treated as the base of the new bridge.

Observed mismatches with v1.18.30:

| Legacy assumption | v1.18.30 contract | Consequence |
|---|---|---|
| `tool.definition` has nested tool name | hook input has `toolID` | route appendix likely not applied |
| `tool.execute.after` has `tool.name` | `tool` is a string | untrusted-tool guard lookup likely misses |
| system transform output is string/messages | `system` is `string[]` | routing injection incompatible |
| system transform input contains user messages | input contains session/model context | text routing cannot see intended request |
| guard subprocess runs synchronously | plugin host is async | host blocking / latency risk |

Recommendation: retire it from runtime, preserve only policy sources in Harness core.

## E. Upstream issue classes that materially affect architecture

1. External plugin tool registration has had regressions where declared plugin tools were not visible to the model.
2. `tool.execute.after` has existed in type declarations during periods where runtime invocation was broken.
3. Plugin hook ordering/error propagation has produced cross-plugin coupling in released versions.
4. Structured output has had retry implementation mismatches and model/provider-specific failures.

These are not reasons to avoid plugins. They are reasons to ship a compatibility lab.

## F. Compatibility certification record

Each certified OpenCode version should have a checked record:

```json
{
  "opencode": "1.18.30",
  "plugin": "0.1.0",
  "protocol": "1.0",
  "platforms": ["windows-amd64"],
  "features": {
    "plugin_load": "pass",
    "tool_registration": "pass",
    "tool_context": "pass",
    "dispose": "pass",
    "sdk_session_create": "pass",
    "child_parent_id": "pass",
    "session_prompt": "pass",
    "session_abort": "pass",
    "structured_output": "conditional"
  },
  "known_limitations": []
}
```

Do not use a broad semver range in marketing/support until each minor line is actually tested.

## G. Minimum host probes

At startup/doctor time:

```text
OpenCode health/version
plugin loaded
bridge handshake
session SDK available
session create/prompt/abort methods present
directory/worktree available
legacy plugin conflict absent
```

At acceptance time:

```text
harness_status tool visible
harness_run tool visible and callable
child session parent relation retained
internal semantic worker cannot call harness_*
provider/model result captured
structured-output mode observed
```

## H. Compatibility fallback hierarchy

Preferred runtime transports:

```text
1. OPENCODE_PLUGIN_SDK   Desktop/native plugin host
2. OPENCODE_SERVER      headless server deployment
3. OPENCODE_CLI         portable fallback
4. TEST_PROCESS         deterministic fixtures only
```

Provider identity and transport identity must remain separate fields.

## I. What not to depend on

Do not make production correctness depend on:

- Desktop private IPC;
- renderer internals;
- sidecar file locations;
- hook ordering relative to unrelated third-party plugins;
- `tool.execute.after` firing;
- global system prompt mutation;
- structured-output retry count being honored;
- a model supporting a particular structured-output lowering strategy;
- process cwd equaling the project root.
